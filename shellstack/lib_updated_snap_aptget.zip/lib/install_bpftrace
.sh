echo "Will now install install_bpftrace
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bpftrace

	echo "install_bpftrace
 has been installed"
	sleep 3
