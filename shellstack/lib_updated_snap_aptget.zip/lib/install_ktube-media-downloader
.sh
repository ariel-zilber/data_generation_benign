echo "Will now install install_ktube-media-downloader
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ktube-media-downloader

	echo "install_ktube-media-downloader
 has been installed"
	sleep 3
