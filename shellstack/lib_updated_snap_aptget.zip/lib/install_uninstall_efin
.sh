echo "Will now install install_uninstall_efin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install efin

sudo snap remove efin

	echo "install_uninstall_efin
 has been installed"
	sleep 3
