echo "Will now install install_uninstall_linkedin-webapp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install linkedin-webapp

sudo snap remove linkedin-webapp

	echo "install_uninstall_linkedin-webapp
 has been installed"
	sleep 3
