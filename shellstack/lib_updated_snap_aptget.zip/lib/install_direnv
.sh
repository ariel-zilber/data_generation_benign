echo "Will now install install_direnv
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install direnv

	echo "install_direnv
 has been installed"
	sleep 3
