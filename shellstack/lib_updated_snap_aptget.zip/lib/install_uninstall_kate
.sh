echo "Will now install install_uninstall_kate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kate

sudo snap remove kate

	echo "install_uninstall_kate
 has been installed"
	sleep 3
