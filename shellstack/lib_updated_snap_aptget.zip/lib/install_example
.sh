echo "Will now install install_example
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install example

	echo "install_example
 has been installed"
	sleep 3
