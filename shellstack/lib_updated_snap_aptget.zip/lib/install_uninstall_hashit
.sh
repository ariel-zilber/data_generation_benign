echo "Will now install install_uninstall_hashit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hashit

sudo snap remove hashit

	echo "install_uninstall_hashit
 has been installed"
	sleep 3
