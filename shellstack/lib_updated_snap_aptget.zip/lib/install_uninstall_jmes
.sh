echo "Will now install install_uninstall_jmes
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jmes

sudo snap remove jmes

	echo "install_uninstall_jmes
 has been installed"
	sleep 3
