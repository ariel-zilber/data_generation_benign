echo "Will now install install_humm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install humm

	echo "install_humm
 has been installed"
	sleep 3
