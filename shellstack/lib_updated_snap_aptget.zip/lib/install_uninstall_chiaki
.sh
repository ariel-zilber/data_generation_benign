echo "Will now install install_uninstall_chiaki
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install chiaki

sudo snap remove chiaki

	echo "install_uninstall_chiaki
 has been installed"
	sleep 3
