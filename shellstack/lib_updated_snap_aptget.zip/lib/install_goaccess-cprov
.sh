echo "Will now install install_goaccess-cprov
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install goaccess-cprov

	echo "install_goaccess-cprov
 has been installed"
	sleep 3
