echo "Will now install install_uninstall_dm-tools
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dm-tools

sudo snap remove dm-tools

	echo "install_uninstall_dm-tools
 has been installed"
	sleep 3
