echo "Will now install install_liveforspeed
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install liveforspeed

	echo "install_liveforspeed
 has been installed"
	sleep 3
