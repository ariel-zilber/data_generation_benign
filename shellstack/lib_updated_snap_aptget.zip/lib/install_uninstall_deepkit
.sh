echo "Will now install install_uninstall_deepkit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install deepkit

sudo snap remove deepkit

	echo "install_uninstall_deepkit
 has been installed"
	sleep 3
