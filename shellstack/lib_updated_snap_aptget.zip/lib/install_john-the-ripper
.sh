echo "Will now install install_john-the-ripper
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install john-the-ripper

	echo "install_john-the-ripper
 has been installed"
	sleep 3
