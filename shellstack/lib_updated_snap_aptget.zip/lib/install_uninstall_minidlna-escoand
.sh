echo "Will now install install_uninstall_minidlna-escoand
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install minidlna-escoand

sudo snap remove minidlna-escoand

	echo "install_uninstall_minidlna-escoand
 has been installed"
	sleep 3
