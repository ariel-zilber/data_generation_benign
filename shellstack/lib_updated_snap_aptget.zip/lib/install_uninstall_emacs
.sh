echo "Will now install install_uninstall_emacs
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install emacs

sudo snap remove emacs

	echo "install_uninstall_emacs
 has been installed"
	sleep 3
