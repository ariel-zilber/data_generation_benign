echo "Will now install install_uninstall_eucalyptus-tools
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eucalyptus-tools

sudo snap remove eucalyptus-tools

	echo "install_uninstall_eucalyptus-tools
 has been installed"
	sleep 3
