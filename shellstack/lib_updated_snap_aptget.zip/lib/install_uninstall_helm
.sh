echo "Will now install install_uninstall_helm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install helm

sudo snap remove helm

	echo "install_uninstall_helm
 has been installed"
	sleep 3
