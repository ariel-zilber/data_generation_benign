echo "Will now install install_uninstall_enonic
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install enonic

sudo snap remove enonic

	echo "install_uninstall_enonic
 has been installed"
	sleep 3
