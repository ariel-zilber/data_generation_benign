echo "Will now install install_uninstall_inoxision-webclient
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install inoxision-webclient

sudo snap remove inoxision-webclient

	echo "install_uninstall_inoxision-webclient
 has been installed"
	sleep 3
