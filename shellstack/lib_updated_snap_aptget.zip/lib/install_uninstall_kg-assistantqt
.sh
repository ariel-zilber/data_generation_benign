echo "Will now install install_uninstall_kg-assistantqt
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kg-assistantqt

sudo snap remove kg-assistantqt

	echo "install_uninstall_kg-assistantqt
 has been installed"
	sleep 3
