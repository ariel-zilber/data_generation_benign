echo "Will now install install_discord
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install discord

	echo "install_discord
 has been installed"
	sleep 3
