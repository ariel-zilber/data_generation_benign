echo "Will now install install_uninstall_applejuice-core
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install applejuice-core

sudo snap remove applejuice-core

	echo "install_uninstall_applejuice-core
 has been installed"
	sleep 3
