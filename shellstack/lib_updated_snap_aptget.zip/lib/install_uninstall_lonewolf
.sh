echo "Will now install install_uninstall_lonewolf
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lonewolf

sudo snap remove lonewolf

	echo "install_uninstall_lonewolf
 has been installed"
	sleep 3
