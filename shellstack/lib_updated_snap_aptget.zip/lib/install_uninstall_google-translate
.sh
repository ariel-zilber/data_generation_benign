echo "Will now install install_uninstall_google-translate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install google-translate

sudo snap remove google-translate

	echo "install_uninstall_google-translate
 has been installed"
	sleep 3
