echo "Will now install install_uninstall_heroku
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install heroku

sudo snap remove heroku

	echo "install_uninstall_heroku
 has been installed"
	sleep 3
