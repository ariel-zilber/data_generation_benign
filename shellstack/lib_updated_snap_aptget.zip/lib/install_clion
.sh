echo "Will now install install_clion
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install clion

	echo "install_clion
 has been installed"
	sleep 3
