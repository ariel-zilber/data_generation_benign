echo "Will now install install_uninstall_bomber
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bomber

sudo snap remove bomber

	echo "install_uninstall_bomber
 has been installed"
	sleep 3
