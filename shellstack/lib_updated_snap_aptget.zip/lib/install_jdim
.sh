echo "Will now install install_jdim
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jdim

	echo "install_jdim
 has been installed"
	sleep 3
