echo "Will now install install_h2e-smart-home
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install h2e-smart-home

	echo "install_h2e-smart-home
 has been installed"
	sleep 3
