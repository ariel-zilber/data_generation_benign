echo "Will now install install_juju-crashdump
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install juju-crashdump

	echo "install_juju-crashdump
 has been installed"
	sleep 3
