echo "Will now install install_gifcurry
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gifcurry

	echo "install_gifcurry
 has been installed"
	sleep 3
