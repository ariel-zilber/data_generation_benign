echo "Will now install install_uninstall_gog-galaxy-wine
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gog-galaxy-wine

sudo snap remove gog-galaxy-wine

	echo "install_uninstall_gog-galaxy-wine
 has been installed"
	sleep 3
