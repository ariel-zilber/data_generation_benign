echo "Will now install install_uninstall_amparepngtoico
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install amparepngtoico

sudo snap remove amparepngtoico

	echo "install_uninstall_amparepngtoico
 has been installed"
	sleep 3
