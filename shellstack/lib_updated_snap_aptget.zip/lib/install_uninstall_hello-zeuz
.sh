echo "Will now install install_uninstall_hello-zeuz
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hello-zeuz

sudo snap remove hello-zeuz

	echo "install_uninstall_hello-zeuz
 has been installed"
	sleep 3
