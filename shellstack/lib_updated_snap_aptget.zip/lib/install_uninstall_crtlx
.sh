echo "Will now install install_uninstall_crtlx
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install crtlx

sudo snap remove crtlx

	echo "install_uninstall_crtlx
 has been installed"
	sleep 3
