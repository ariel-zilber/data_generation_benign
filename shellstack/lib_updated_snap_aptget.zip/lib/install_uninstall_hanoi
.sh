echo "Will now install install_uninstall_hanoi
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hanoi

sudo snap remove hanoi

	echo "install_uninstall_hanoi
 has been installed"
	sleep 3
