echo "Will now install install_directpdf
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install directpdf

	echo "install_directpdf
 has been installed"
	sleep 3
