echo "Will now install install_uninstall_clementine
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install clementine

sudo snap remove clementine

	echo "install_uninstall_clementine
 has been installed"
	sleep 3
