echo "Will now install install_uninstall_insomnia
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install insomnia

sudo snap remove insomnia

	echo "install_uninstall_insomnia
 has been installed"
	sleep 3
