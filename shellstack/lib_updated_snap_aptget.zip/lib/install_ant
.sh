echo "Will now install install_ant
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ant

	echo "install_ant
 has been installed"
	sleep 3
