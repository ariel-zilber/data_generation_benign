echo "Will now install install_abeato-xlnx-sysroot
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install abeato-xlnx-sysroot

	echo "install_abeato-xlnx-sysroot
 has been installed"
	sleep 3
