echo "Will now install install_uninstall_icemaze
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install icemaze

sudo snap remove icemaze

	echo "install_uninstall_icemaze
 has been installed"
	sleep 3
