echo "Will now install install_uninstall_juju-verify
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install juju-verify

sudo snap remove juju-verify

	echo "install_uninstall_juju-verify
 has been installed"
	sleep 3
