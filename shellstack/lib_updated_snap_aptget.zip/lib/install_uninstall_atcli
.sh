echo "Will now install install_uninstall_atcli
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install atcli

sudo snap remove atcli

	echo "install_uninstall_atcli
 has been installed"
	sleep 3
