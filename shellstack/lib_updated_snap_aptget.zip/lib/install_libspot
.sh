echo "Will now install install_libspot
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install libspot

	echo "install_libspot
 has been installed"
	sleep 3
