echo "Will now install install_gnome-mahjongg
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-mahjongg

	echo "install_gnome-mahjongg
 has been installed"
	sleep 3
