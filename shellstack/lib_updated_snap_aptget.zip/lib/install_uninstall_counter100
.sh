echo "Will now install install_uninstall_counter100
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install counter100

sudo snap remove counter100

	echo "install_uninstall_counter100
 has been installed"
	sleep 3
