echo "Will now install install_uninstall_busybox-static
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install busybox-static

sudo snap remove busybox-static

	echo "install_uninstall_busybox-static
 has been installed"
	sleep 3
