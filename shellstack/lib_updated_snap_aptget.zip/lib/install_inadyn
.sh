echo "Will now install install_inadyn
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install inadyn

	echo "install_inadyn
 has been installed"
	sleep 3
