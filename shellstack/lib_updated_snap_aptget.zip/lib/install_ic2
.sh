echo "Will now install install_ic2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ic2

	echo "install_ic2
 has been installed"
	sleep 3
