echo "Will now install install_uninstall_googler
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install googler

sudo snap remove googler

	echo "install_uninstall_googler
 has been installed"
	sleep 3
