echo "Will now install install_bare
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bare

	echo "install_bare
 has been installed"
	sleep 3
