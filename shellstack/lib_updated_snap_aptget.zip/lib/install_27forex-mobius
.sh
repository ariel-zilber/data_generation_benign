echo "Will now install install_27forex-mobius
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 27forex-mobius

	echo "install_27forex-mobius
 has been installed"
	sleep 3
