echo "Will now install install_uninstall_inadyn
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install inadyn

sudo snap remove inadyn

	echo "install_uninstall_inadyn
 has been installed"
	sleep 3
