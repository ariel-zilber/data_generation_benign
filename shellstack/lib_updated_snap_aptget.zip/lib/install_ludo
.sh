echo "Will now install install_ludo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ludo

	echo "install_ludo
 has been installed"
	sleep 3
