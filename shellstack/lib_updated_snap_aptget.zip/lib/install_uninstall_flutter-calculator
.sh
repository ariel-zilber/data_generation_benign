echo "Will now install install_uninstall_flutter-calculator
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flutter-calculator

sudo snap remove flutter-calculator

	echo "install_uninstall_flutter-calculator
 has been installed"
	sleep 3
