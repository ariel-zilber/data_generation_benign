echo "Will now install install_uninstall_gotop-cjbassi
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gotop-cjbassi

sudo snap remove gotop-cjbassi

	echo "install_uninstall_gotop-cjbassi
 has been installed"
	sleep 3
