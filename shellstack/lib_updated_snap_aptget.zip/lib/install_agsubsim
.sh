echo "Will now install install_agsubsim
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install agsubsim

	echo "install_agsubsim
 has been installed"
	sleep 3
