echo "Will now install install_uninstall_malia
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install malia

sudo snap remove malia

	echo "install_uninstall_malia
 has been installed"
	sleep 3
