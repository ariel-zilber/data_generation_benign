echo "Will now install install_uninstall_kblackbox
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kblackbox

sudo snap remove kblackbox

	echo "install_uninstall_kblackbox
 has been installed"
	sleep 3
