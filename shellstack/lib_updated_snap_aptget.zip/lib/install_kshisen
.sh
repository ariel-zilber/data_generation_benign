echo "Will now install install_kshisen
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kshisen

	echo "install_kshisen
 has been installed"
	sleep 3
