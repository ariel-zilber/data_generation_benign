echo "Will now install install_blix
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install blix

	echo "install_blix
 has been installed"
	sleep 3
