echo "Will now install install_led01
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install led01

	echo "install_led01
 has been installed"
	sleep 3
