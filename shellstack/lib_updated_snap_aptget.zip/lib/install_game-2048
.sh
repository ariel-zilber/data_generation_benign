echo "Will now install install_game-2048
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install game-2048

	echo "install_game-2048
 has been installed"
	sleep 3
