echo "Will now install install_folding-at-home-fcole90
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install folding-at-home-fcole90

	echo "install_folding-at-home-fcole90
 has been installed"
	sleep 3
