echo "Will now install install_uninstall_freeman
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install freeman

sudo snap remove freeman

	echo "install_uninstall_freeman
 has been installed"
	sleep 3
