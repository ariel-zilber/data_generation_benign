echo "Will now install install_uninstall_joplin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install joplin

sudo snap remove joplin

	echo "install_uninstall_joplin
 has been installed"
	sleep 3
