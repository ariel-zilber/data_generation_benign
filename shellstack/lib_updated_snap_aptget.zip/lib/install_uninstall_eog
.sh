echo "Will now install install_uninstall_eog
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eog

sudo snap remove eog

	echo "install_uninstall_eog
 has been installed"
	sleep 3
