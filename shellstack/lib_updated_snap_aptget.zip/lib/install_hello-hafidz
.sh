echo "Will now install install_hello-hafidz
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hello-hafidz

	echo "install_hello-hafidz
 has been installed"
	sleep 3
