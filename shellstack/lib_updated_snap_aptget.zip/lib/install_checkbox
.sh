echo "Will now install install_checkbox
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox

	echo "install_checkbox
 has been installed"
	sleep 3
