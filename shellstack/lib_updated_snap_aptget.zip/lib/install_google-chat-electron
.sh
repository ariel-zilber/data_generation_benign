echo "Will now install install_google-chat-electron
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install google-chat-electron

	echo "install_google-chat-electron
 has been installed"
	sleep 3
