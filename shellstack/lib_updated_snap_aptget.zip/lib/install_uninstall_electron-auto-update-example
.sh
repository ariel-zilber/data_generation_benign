echo "Will now install install_uninstall_electron-auto-update-example
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electron-auto-update-example

sudo snap remove electron-auto-update-example

	echo "install_uninstall_electron-auto-update-example
 has been installed"
	sleep 3
