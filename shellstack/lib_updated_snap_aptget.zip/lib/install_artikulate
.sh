echo "Will now install install_artikulate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install artikulate

	echo "install_artikulate
 has been installed"
	sleep 3
