echo "Will now install install_jmes
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jmes

	echo "install_jmes
 has been installed"
	sleep 3
