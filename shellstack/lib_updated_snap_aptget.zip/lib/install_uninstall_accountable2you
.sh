echo "Will now install install_uninstall_accountable2you
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install accountable2you

sudo snap remove accountable2you

	echo "install_uninstall_accountable2you
 has been installed"
	sleep 3
