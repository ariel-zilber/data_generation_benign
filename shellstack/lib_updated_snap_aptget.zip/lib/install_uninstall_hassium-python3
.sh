echo "Will now install install_uninstall_hassium-python3
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hassium-python3

sudo snap remove hassium-python3

	echo "install_uninstall_hassium-python3
 has been installed"
	sleep 3
