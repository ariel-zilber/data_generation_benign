echo "Will now install install_uninstall_1password
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 1password

sudo snap remove 1password

	echo "install_uninstall_1password
 has been installed"
	sleep 3
