echo "Will now install install_bluemail
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bluemail

	echo "install_bluemail
 has been installed"
	sleep 3
