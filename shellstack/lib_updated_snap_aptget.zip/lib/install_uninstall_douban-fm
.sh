echo "Will now install install_uninstall_douban-fm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install douban-fm

sudo snap remove douban-fm

	echo "install_uninstall_douban-fm
 has been installed"
	sleep 3
