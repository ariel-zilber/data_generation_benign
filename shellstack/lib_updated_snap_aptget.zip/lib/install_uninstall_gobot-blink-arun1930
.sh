echo "Will now install install_uninstall_gobot-blink-arun1930
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gobot-blink-arun1930

sudo snap remove gobot-blink-arun1930

	echo "install_uninstall_gobot-blink-arun1930
 has been installed"
	sleep 3
