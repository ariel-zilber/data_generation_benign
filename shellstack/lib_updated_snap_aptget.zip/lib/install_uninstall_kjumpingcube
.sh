echo "Will now install install_uninstall_kjumpingcube
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kjumpingcube

sudo snap remove kjumpingcube

	echo "install_uninstall_kjumpingcube
 has been installed"
	sleep 3
