echo "Will now install install_uninstall_cornyjokes
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cornyjokes

sudo snap remove cornyjokes

	echo "install_uninstall_cornyjokes
 has been installed"
	sleep 3
