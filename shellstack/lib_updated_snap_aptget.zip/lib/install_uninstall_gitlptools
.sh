echo "Will now install install_uninstall_gitlptools
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gitlptools

sudo snap remove gitlptools

	echo "install_uninstall_gitlptools
 has been installed"
	sleep 3
