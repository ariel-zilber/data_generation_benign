echo "Will now install install_hashit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hashit

	echo "install_hashit
 has been installed"
	sleep 3
