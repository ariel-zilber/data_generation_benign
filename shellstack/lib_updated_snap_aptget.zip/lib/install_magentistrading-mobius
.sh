echo "Will now install install_magentistrading-mobius
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install magentistrading-mobius

	echo "install_magentistrading-mobius
 has been installed"
	sleep 3
