echo "Will now install install_uninstall_anta-i7z
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install anta-i7z

sudo snap remove anta-i7z

	echo "install_uninstall_anta-i7z
 has been installed"
	sleep 3
