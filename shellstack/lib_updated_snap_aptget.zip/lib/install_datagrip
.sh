echo "Will now install install_datagrip
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install datagrip

	echo "install_datagrip
 has been installed"
	sleep 3
