echo "Will now install install_buka
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install buka

	echo "install_buka
 has been installed"
	sleep 3
