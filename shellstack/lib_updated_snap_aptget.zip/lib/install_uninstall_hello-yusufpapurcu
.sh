echo "Will now install install_uninstall_hello-yusufpapurcu
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hello-yusufpapurcu

sudo snap remove hello-yusufpapurcu

	echo "install_uninstall_hello-yusufpapurcu
 has been installed"
	sleep 3
