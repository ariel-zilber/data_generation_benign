echo "Will now install install_uninstall_cdcat-catalog
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cdcat-catalog

sudo snap remove cdcat-catalog

	echo "install_uninstall_cdcat-catalog
 has been installed"
	sleep 3
