echo "Will now install install_uninstall_grin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install grin

sudo snap remove grin

	echo "install_uninstall_grin
 has been installed"
	sleep 3
