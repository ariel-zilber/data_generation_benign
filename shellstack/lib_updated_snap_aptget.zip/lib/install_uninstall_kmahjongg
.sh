echo "Will now install install_uninstall_kmahjongg
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kmahjongg

sudo snap remove kmahjongg

	echo "install_uninstall_kmahjongg
 has been installed"
	sleep 3
