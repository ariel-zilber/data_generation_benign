echo "Will now install install_mdtex
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install mdtex

	echo "install_mdtex
 has been installed"
	sleep 3
