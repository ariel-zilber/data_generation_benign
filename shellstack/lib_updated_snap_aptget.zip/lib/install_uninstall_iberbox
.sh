echo "Will now install install_uninstall_iberbox
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iberbox

sudo snap remove iberbox

	echo "install_uninstall_iberbox
 has been installed"
	sleep 3
