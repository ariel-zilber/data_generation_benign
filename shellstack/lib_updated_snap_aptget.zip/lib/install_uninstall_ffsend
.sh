echo "Will now install install_uninstall_ffsend
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ffsend

sudo snap remove ffsend

	echo "install_uninstall_ffsend
 has been installed"
	sleep 3
