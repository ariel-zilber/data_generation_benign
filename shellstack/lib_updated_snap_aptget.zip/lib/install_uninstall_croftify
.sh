echo "Will now install install_uninstall_croftify
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install croftify

sudo snap remove croftify

	echo "install_uninstall_croftify
 has been installed"
	sleep 3
