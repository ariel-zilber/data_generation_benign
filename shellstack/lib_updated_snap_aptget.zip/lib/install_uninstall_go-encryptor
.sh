echo "Will now install install_uninstall_go-encryptor
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install go-encryptor

sudo snap remove go-encryptor

	echo "install_uninstall_go-encryptor
 has been installed"
	sleep 3
