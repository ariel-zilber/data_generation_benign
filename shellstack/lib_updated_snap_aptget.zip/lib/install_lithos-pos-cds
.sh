echo "Will now install install_lithos-pos-cds
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lithos-pos-cds

	echo "install_lithos-pos-cds
 has been installed"
	sleep 3
