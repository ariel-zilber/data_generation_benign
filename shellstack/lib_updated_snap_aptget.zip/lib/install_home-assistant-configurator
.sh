echo "Will now install install_home-assistant-configurator
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install home-assistant-configurator

	echo "install_home-assistant-configurator
 has been installed"
	sleep 3
