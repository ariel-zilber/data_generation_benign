echo "Will now install install_ktimer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ktimer

	echo "install_ktimer
 has been installed"
	sleep 3
