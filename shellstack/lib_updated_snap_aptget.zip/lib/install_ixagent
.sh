echo "Will now install install_ixagent
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ixagent

	echo "install_ixagent
 has been installed"
	sleep 3
