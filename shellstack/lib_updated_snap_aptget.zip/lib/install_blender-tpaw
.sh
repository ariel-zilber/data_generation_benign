echo "Will now install install_blender-tpaw
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install blender-tpaw

	echo "install_blender-tpaw
 has been installed"
	sleep 3
