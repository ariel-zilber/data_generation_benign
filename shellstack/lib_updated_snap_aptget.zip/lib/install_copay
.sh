echo "Will now install install_copay
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install copay

	echo "install_copay
 has been installed"
	sleep 3
