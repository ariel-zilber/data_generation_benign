echo "Will now install install_uninstall_emote
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install emote

sudo snap remove emote

	echo "install_uninstall_emote
 has been installed"
	sleep 3
