echo "Will now install install_uninstall_ktuberling
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ktuberling

sudo snap remove ktuberling

	echo "install_uninstall_ktuberling
 has been installed"
	sleep 3
