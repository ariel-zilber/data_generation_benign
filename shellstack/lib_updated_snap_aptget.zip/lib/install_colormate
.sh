echo "Will now install install_colormate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install colormate

	echo "install_colormate
 has been installed"
	sleep 3
