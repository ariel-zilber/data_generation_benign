echo "Will now install install_gorched
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gorched

	echo "install_gorched
 has been installed"
	sleep 3
