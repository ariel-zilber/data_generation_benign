echo "Will now install install_image-optimizer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install image-optimizer

	echo "install_image-optimizer
 has been installed"
	sleep 3
