echo "Will now install install_agave-colorscheme
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install agave-colorscheme

	echo "install_agave-colorscheme
 has been installed"
	sleep 3
