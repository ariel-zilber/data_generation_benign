echo "Will now install install_uninstall_idris2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install idris2

sudo snap remove idris2

	echo "install_uninstall_idris2
 has been installed"
	sleep 3
