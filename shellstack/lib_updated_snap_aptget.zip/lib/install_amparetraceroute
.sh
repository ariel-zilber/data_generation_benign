echo "Will now install install_amparetraceroute
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install amparetraceroute

	echo "install_amparetraceroute
 has been installed"
	sleep 3
