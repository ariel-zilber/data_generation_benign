echo "Will now install install_uninstall_dingtalk-notifier
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dingtalk-notifier

sudo snap remove dingtalk-notifier

	echo "install_uninstall_dingtalk-notifier
 has been installed"
	sleep 3
