echo "Will now install install_dotnet-runtime-21
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dotnet-runtime-21

	echo "install_dotnet-runtime-21
 has been installed"
	sleep 3
