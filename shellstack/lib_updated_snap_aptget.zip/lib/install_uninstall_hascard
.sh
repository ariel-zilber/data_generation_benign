echo "Will now install install_uninstall_hascard
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hascard

sudo snap remove hascard

	echo "install_uninstall_hascard
 has been installed"
	sleep 3
