echo "Will now install install_fortask
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fortask

	echo "install_fortask
 has been installed"
	sleep 3
