echo "Will now install install_uninstall_easyorg
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install easyorg

sudo snap remove easyorg

	echo "install_uninstall_easyorg
 has been installed"
	sleep 3
