echo "Will now install install_uninstall_gopls
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gopls

sudo snap remove gopls

	echo "install_uninstall_gopls
 has been installed"
	sleep 3
