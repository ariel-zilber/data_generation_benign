echo "Will now install install_uninstall_ipfs-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ipfs-desktop

sudo snap remove ipfs-desktop

	echo "install_uninstall_ipfs-desktop
 has been installed"
	sleep 3
