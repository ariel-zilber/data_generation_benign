echo "Will now install install_lapin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lapin

	echo "install_lapin
 has been installed"
	sleep 3
