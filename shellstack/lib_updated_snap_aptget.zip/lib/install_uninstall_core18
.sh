echo "Will now install install_uninstall_core18
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install core18

sudo snap remove core18

	echo "install_uninstall_core18
 has been installed"
	sleep 3
