echo "Will now install install_lindhe-cloudflare-ddns
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lindhe-cloudflare-ddns

	echo "install_lindhe-cloudflare-ddns
 has been installed"
	sleep 3
