echo "Will now install install_bastis-test-snap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bastis-test-snap

	echo "install_bastis-test-snap
 has been installed"
	sleep 3
