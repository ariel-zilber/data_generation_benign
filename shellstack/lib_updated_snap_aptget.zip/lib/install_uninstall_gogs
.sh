echo "Will now install install_uninstall_gogs
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gogs

sudo snap remove gogs

	echo "install_uninstall_gogs
 has been installed"
	sleep 3
