echo "Will now install install_keepassx-elopio
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install keepassx-elopio

	echo "install_keepassx-elopio
 has been installed"
	sleep 3
