echo "Will now install install_magicraminstaller
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install magicraminstaller

	echo "install_magicraminstaller
 has been installed"
	sleep 3
