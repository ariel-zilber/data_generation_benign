echo "Will now install install_1password-linux
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 1password-linux

	echo "install_1password-linux
 has been installed"
	sleep 3
