echo "Will now install install_jarjar
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jarjar

	echo "install_jarjar
 has been installed"
	sleep 3
