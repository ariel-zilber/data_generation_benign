echo "Will now install install_uninstall_good-job
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install good-job

sudo snap remove good-job

	echo "install_uninstall_good-job
 has been installed"
	sleep 3
