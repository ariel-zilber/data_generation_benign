echo "Will now install install_deepin-image-viewer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install deepin-image-viewer

	echo "install_deepin-image-viewer
 has been installed"
	sleep 3
