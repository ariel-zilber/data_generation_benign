echo "Will now install install_uninstall_hnterm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hnterm

sudo snap remove hnterm

	echo "install_uninstall_hnterm
 has been installed"
	sleep 3
