echo "Will now install install_uninstall_1stmoney
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 1stmoney

sudo snap remove 1stmoney

	echo "install_uninstall_1stmoney
 has been installed"
	sleep 3
