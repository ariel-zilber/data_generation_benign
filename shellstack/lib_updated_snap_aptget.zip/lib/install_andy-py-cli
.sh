echo "Will now install install_andy-py-cli
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install andy-py-cli

	echo "install_andy-py-cli
 has been installed"
	sleep 3
