echo "Will now install install_guiscrcpy
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install guiscrcpy

	echo "install_guiscrcpy
 has been installed"
	sleep 3
