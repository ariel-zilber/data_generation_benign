echo "Will now install install_kiriki
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kiriki

	echo "install_kiriki
 has been installed"
	sleep 3
