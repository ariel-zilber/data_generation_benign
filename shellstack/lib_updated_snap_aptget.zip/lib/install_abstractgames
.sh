echo "Will now install install_abstractgames
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install abstractgames

	echo "install_abstractgames
 has been installed"
	sleep 3
