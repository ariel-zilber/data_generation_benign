echo "Will now install install_iproute2-snap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iproute2-snap

	echo "install_iproute2-snap
 has been installed"
	sleep 3
