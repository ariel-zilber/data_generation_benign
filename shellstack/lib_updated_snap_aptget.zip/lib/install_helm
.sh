echo "Will now install install_helm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install helm

	echo "install_helm
 has been installed"
	sleep 3
