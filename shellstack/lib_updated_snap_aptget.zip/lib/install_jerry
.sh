echo "Will now install install_jerry
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jerry

	echo "install_jerry
 has been installed"
	sleep 3
