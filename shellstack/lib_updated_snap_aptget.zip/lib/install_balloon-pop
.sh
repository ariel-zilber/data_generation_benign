echo "Will now install install_balloon-pop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install balloon-pop

	echo "install_balloon-pop
 has been installed"
	sleep 3
