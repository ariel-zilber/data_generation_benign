echo "Will now install install_humble-toolbox
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install humble-toolbox

	echo "install_humble-toolbox
 has been installed"
	sleep 3
