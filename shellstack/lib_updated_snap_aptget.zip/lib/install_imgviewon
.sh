echo "Will now install install_imgviewon
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install imgviewon

	echo "install_imgviewon
 has been installed"
	sleep 3
