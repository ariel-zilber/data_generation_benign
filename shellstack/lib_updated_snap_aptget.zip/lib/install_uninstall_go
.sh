echo "Will now install install_uninstall_go
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install go

sudo snap remove go

	echo "install_uninstall_go
 has been installed"
	sleep 3
