echo "Will now install install_christmas-obfuscated-c
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install christmas-obfuscated-c

	echo "install_christmas-obfuscated-c
 has been installed"
	sleep 3
