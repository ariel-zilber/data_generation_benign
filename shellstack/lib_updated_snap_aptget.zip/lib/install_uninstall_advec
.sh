echo "Will now install install_uninstall_advec
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install advec

sudo snap remove advec

	echo "install_uninstall_advec
 has been installed"
	sleep 3
