echo "Will now install install_justsurfinthenet
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install justsurfinthenet

	echo "install_justsurfinthenet
 has been installed"
	sleep 3
