echo "Will now install install_kbounce
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kbounce

	echo "install_kbounce
 has been installed"
	sleep 3
