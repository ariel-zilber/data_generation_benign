echo "Will now install install_flif
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flif

	echo "install_flif
 has been installed"
	sleep 3
