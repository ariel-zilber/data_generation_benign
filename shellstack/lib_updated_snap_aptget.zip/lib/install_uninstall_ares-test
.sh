echo "Will now install install_uninstall_ares-test
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ares-test

sudo snap remove ares-test

	echo "install_uninstall_ares-test
 has been installed"
	sleep 3
