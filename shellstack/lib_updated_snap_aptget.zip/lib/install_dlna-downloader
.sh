echo "Will now install install_dlna-downloader
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dlna-downloader

	echo "install_dlna-downloader
 has been installed"
	sleep 3
