echo "Will now install install_uninstall_contasimple
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install contasimple

sudo snap remove contasimple

	echo "install_uninstall_contasimple
 has been installed"
	sleep 3
