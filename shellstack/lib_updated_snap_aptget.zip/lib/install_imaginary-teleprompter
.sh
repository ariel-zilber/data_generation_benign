echo "Will now install install_imaginary-teleprompter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install imaginary-teleprompter

	echo "install_imaginary-teleprompter
 has been installed"
	sleep 3
