echo "Will now install install_inspirer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install inspirer

	echo "install_inspirer
 has been installed"
	sleep 3
