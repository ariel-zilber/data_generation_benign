echo "Will now install install_elliptic-curve-plotter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install elliptic-curve-plotter

	echo "install_elliptic-curve-plotter
 has been installed"
	sleep 3
