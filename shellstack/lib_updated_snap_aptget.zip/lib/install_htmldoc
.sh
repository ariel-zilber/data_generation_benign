echo "Will now install install_htmldoc
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install htmldoc

	echo "install_htmldoc
 has been installed"
	sleep 3
