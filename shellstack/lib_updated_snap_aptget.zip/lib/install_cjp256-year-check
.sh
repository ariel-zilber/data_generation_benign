echo "Will now install install_cjp256-year-check
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cjp256-year-check

	echo "install_cjp256-year-check
 has been installed"
	sleep 3
