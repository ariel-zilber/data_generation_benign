echo "Will now install install_uninstall_kde-frameworks-5
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kde-frameworks-5

sudo snap remove kde-frameworks-5

	echo "install_uninstall_kde-frameworks-5
 has been installed"
	sleep 3
