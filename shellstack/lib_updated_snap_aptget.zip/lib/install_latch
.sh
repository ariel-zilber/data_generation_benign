echo "Will now install install_latch
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install latch

	echo "install_latch
 has been installed"
	sleep 3
