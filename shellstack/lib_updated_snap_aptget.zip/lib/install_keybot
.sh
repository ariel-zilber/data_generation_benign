echo "Will now install install_keybot
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install keybot

	echo "install_keybot
 has been installed"
	sleep 3
