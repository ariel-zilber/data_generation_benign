echo "Will now install install_uninstall_blur
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install blur

sudo snap remove blur

	echo "install_uninstall_blur
 has been installed"
	sleep 3
