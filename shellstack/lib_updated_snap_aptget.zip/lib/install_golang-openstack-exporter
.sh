echo "Will now install install_golang-openstack-exporter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install golang-openstack-exporter

	echo "install_golang-openstack-exporter
 has been installed"
	sleep 3
