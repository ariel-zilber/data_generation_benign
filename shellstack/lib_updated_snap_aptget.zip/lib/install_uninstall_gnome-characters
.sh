echo "Will now install install_uninstall_gnome-characters
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-characters

sudo snap remove gnome-characters

	echo "install_uninstall_gnome-characters
 has been installed"
	sleep 3
