echo "Will now install install_hellolib
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hellolib

	echo "install_hellolib
 has been installed"
	sleep 3
