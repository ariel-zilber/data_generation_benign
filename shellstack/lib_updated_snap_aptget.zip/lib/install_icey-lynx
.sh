echo "Will now install install_icey-lynx
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install icey-lynx

	echo "install_icey-lynx
 has been installed"
	sleep 3
