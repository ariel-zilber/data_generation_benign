echo "Will now install install_uninstall_killbots
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install killbots

sudo snap remove killbots

	echo "install_uninstall_killbots
 has been installed"
	sleep 3
