echo "Will now install install_goathtool
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install goathtool

	echo "install_goathtool
 has been installed"
	sleep 3
