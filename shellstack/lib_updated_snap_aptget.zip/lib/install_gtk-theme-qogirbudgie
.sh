echo "Will now install install_gtk-theme-qogirbudgie
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gtk-theme-qogirbudgie

	echo "install_gtk-theme-qogirbudgie
 has been installed"
	sleep 3
