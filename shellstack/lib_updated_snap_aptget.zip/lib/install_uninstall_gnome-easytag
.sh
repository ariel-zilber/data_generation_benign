echo "Will now install install_uninstall_gnome-easytag
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-easytag

sudo snap remove gnome-easytag

	echo "install_uninstall_gnome-easytag
 has been installed"
	sleep 3
