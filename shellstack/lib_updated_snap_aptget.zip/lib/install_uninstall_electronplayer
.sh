echo "Will now install install_uninstall_electronplayer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electronplayer

sudo snap remove electronplayer

	echo "install_uninstall_electronplayer
 has been installed"
	sleep 3
