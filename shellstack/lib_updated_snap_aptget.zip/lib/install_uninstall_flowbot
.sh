echo "Will now install install_uninstall_flowbot
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flowbot

sudo snap remove flowbot

	echo "install_uninstall_flowbot
 has been installed"
	sleep 3
