echo "Will now install install_amparepdftoimage
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install amparepdftoimage

	echo "install_amparepdftoimage
 has been installed"
	sleep 3
