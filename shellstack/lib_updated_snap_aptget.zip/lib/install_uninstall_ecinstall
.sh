echo "Will now install install_uninstall_ecinstall
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ecinstall

sudo snap remove ecinstall

	echo "install_uninstall_ecinstall
 has been installed"
	sleep 3
