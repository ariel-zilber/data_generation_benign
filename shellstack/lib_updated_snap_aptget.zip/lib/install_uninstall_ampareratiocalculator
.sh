echo "Will now install install_uninstall_ampareratiocalculator
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ampareratiocalculator

sudo snap remove ampareratiocalculator

	echo "install_uninstall_ampareratiocalculator
 has been installed"
	sleep 3
