echo "Will now install install_uninstall_confid
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install confid

sudo snap remove confid

	echo "install_uninstall_confid
 has been installed"
	sleep 3
