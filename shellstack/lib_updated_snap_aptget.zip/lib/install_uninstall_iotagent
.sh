echo "Will now install install_uninstall_iotagent
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iotagent

sudo snap remove iotagent

	echo "install_uninstall_iotagent
 has been installed"
	sleep 3
