echo "Will now install install_jindosbox
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jindosbox

	echo "install_jindosbox
 has been installed"
	sleep 3
