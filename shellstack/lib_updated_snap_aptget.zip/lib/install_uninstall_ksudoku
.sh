echo "Will now install install_uninstall_ksudoku
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ksudoku

sudo snap remove ksudoku

	echo "install_uninstall_ksudoku
 has been installed"
	sleep 3
