echo "Will now install install_freac
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install freac

	echo "install_freac
 has been installed"
	sleep 3
