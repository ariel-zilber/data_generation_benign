echo "Will now install install_uninstall_foliate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install foliate

sudo snap remove foliate

	echo "install_uninstall_foliate
 has been installed"
	sleep 3
