echo "Will now install install_uninstall_jenkins-carla
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jenkins-carla

sudo snap remove jenkins-carla

	echo "install_uninstall_jenkins-carla
 has been installed"
	sleep 3
