echo "Will now install install_uninstall_icon-theme-yaru-mate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install icon-theme-yaru-mate

sudo snap remove icon-theme-yaru-mate

	echo "install_uninstall_icon-theme-yaru-mate
 has been installed"
	sleep 3
