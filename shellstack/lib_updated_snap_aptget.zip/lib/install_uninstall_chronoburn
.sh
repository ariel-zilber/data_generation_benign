echo "Will now install install_uninstall_chronoburn
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install chronoburn

sudo snap remove chronoburn

	echo "install_uninstall_chronoburn
 has been installed"
	sleep 3
