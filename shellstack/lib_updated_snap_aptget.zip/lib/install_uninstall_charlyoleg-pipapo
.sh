echo "Will now install install_uninstall_charlyoleg-pipapo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install charlyoleg-pipapo

sudo snap remove charlyoleg-pipapo

	echo "install_uninstall_charlyoleg-pipapo
 has been installed"
	sleep 3
