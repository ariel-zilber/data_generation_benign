echo "Will now install install_uninstall_ipfs
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ipfs

sudo snap remove ipfs

	echo "install_uninstall_ipfs
 has been installed"
	sleep 3
