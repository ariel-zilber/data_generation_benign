echo "Will now install install_chromium-ffmpeg
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install chromium-ffmpeg

	echo "install_chromium-ffmpeg
 has been installed"
	sleep 3
