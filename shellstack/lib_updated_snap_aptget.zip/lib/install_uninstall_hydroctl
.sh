echo "Will now install install_uninstall_hydroctl
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hydroctl

sudo snap remove hydroctl

	echo "install_uninstall_hydroctl
 has been installed"
	sleep 3
