echo "Will now install install_litecoin-core
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install litecoin-core

	echo "install_litecoin-core
 has been installed"
	sleep 3
