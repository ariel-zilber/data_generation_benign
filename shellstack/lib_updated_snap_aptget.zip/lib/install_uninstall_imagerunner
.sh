echo "Will now install install_uninstall_imagerunner
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install imagerunner

sudo snap remove imagerunner

	echo "install_uninstall_imagerunner
 has been installed"
	sleep 3
