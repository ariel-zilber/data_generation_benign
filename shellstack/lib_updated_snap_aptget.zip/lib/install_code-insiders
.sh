echo "Will now install install_code-insiders
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install code-insiders

	echo "install_code-insiders
 has been installed"
	sleep 3
