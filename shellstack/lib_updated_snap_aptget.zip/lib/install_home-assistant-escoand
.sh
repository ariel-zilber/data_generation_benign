echo "Will now install install_home-assistant-escoand
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install home-assistant-escoand

	echo "install_home-assistant-escoand
 has been installed"
	sleep 3
