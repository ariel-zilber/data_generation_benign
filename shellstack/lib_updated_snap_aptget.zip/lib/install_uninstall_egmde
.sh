echo "Will now install install_uninstall_egmde
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install egmde

sudo snap remove egmde

	echo "install_uninstall_egmde
 has been installed"
	sleep 3
