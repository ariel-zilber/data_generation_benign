echo "Will now install install_uninstall_gnome-nibbles
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-nibbles

sudo snap remove gnome-nibbles

	echo "install_uninstall_gnome-nibbles
 has been installed"
	sleep 3
