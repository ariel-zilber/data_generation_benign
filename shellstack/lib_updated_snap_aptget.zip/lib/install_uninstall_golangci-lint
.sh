echo "Will now install install_uninstall_golangci-lint
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install golangci-lint

sudo snap remove golangci-lint

	echo "install_uninstall_golangci-lint
 has been installed"
	sleep 3
