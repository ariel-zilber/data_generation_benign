echo "Will now install install_uninstall_joule-expansion
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install joule-expansion

sudo snap remove joule-expansion

	echo "install_uninstall_joule-expansion
 has been installed"
	sleep 3
