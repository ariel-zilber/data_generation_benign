echo "Will now install install_hexexplorer-snap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hexexplorer-snap

	echo "install_hexexplorer-snap
 has been installed"
	sleep 3
