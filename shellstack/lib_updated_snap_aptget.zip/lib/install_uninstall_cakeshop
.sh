echo "Will now install install_uninstall_cakeshop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cakeshop

sudo snap remove cakeshop

	echo "install_uninstall_cakeshop
 has been installed"
	sleep 3
