echo "Will now install install_uninstall_http
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install http

sudo snap remove http

	echo "install_uninstall_http
 has been installed"
	sleep 3
