echo "Will now install install_cpp-dependencies
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cpp-dependencies

	echo "install_cpp-dependencies
 has been installed"
	sleep 3
