echo "Will now install install_kominal-connect
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kominal-connect

	echo "install_kominal-connect
 has been installed"
	sleep 3
