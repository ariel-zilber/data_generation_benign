echo "Will now install install_audacity
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install audacity

	echo "install_audacity
 has been installed"
	sleep 3
