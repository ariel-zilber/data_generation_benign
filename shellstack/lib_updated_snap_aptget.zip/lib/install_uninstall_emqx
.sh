echo "Will now install install_uninstall_emqx
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install emqx

sudo snap remove emqx

	echo "install_uninstall_emqx
 has been installed"
	sleep 3
