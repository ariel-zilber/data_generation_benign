echo "Will now install install_uninstall_kg-assistant
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kg-assistant

sudo snap remove kg-assistant

	echo "install_uninstall_kg-assistant
 has been installed"
	sleep 3
