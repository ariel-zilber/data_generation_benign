echo "Will now install install_uninstall_flaarum
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flaarum

sudo snap remove flaarum

	echo "install_uninstall_flaarum
 has been installed"
	sleep 3
