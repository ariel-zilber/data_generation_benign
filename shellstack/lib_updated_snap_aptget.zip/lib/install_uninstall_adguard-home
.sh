echo "Will now install install_uninstall_adguard-home
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install adguard-home

sudo snap remove adguard-home

	echo "install_uninstall_adguard-home
 has been installed"
	sleep 3
