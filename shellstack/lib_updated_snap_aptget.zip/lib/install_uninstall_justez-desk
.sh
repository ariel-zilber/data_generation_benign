echo "Will now install install_uninstall_justez-desk
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install justez-desk

sudo snap remove justez-desk

	echo "install_uninstall_justez-desk
 has been installed"
	sleep 3
