echo "Will now install install_uninstall_fluffychat
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fluffychat

sudo snap remove fluffychat

	echo "install_uninstall_fluffychat
 has been installed"
	sleep 3
