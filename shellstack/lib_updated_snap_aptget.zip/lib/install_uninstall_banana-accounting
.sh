echo "Will now install install_uninstall_banana-accounting
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install banana-accounting

sudo snap remove banana-accounting

	echo "install_uninstall_banana-accounting
 has been installed"
	sleep 3
