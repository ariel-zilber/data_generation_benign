echo "Will now install install_uninstall_baugeschichte
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install baugeschichte

sudo snap remove baugeschichte

	echo "install_uninstall_baugeschichte
 has been installed"
	sleep 3
