echo "Will now install install_erlang
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install erlang

	echo "install_erlang
 has been installed"
	sleep 3
