echo "Will now install install_uninstall_dhanaraj-hello
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dhanaraj-hello

sudo snap remove dhanaraj-hello

	echo "install_uninstall_dhanaraj-hello
 has been installed"
	sleep 3
