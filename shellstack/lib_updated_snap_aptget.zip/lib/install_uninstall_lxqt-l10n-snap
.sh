echo "Will now install install_uninstall_lxqt-l10n-snap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lxqt-l10n-snap

sudo snap remove lxqt-l10n-snap

	echo "install_uninstall_lxqt-l10n-snap
 has been installed"
	sleep 3
