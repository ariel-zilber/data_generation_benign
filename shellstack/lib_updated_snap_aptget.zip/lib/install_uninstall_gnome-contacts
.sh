echo "Will now install install_uninstall_gnome-contacts
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-contacts

sudo snap remove gnome-contacts

	echo "install_uninstall_gnome-contacts
 has been installed"
	sleep 3
