echo "Will now install install_uninstall_dino
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dino

sudo snap remove dino

	echo "install_uninstall_dino
 has been installed"
	sleep 3
