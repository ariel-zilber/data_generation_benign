echo "Will now install install_clipaste
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install clipaste

	echo "install_clipaste
 has been installed"
	sleep 3
