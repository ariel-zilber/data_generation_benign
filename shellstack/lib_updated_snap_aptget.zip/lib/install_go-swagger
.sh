echo "Will now install install_go-swagger
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install go-swagger

	echo "install_go-swagger
 has been installed"
	sleep 3
