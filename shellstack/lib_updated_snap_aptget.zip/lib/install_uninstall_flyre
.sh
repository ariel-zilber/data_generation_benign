echo "Will now install install_uninstall_flyre
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flyre

sudo snap remove flyre

	echo "install_uninstall_flyre
 has been installed"
	sleep 3
