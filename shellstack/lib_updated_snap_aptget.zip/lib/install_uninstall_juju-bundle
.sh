echo "Will now install install_uninstall_juju-bundle
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install juju-bundle

sudo snap remove juju-bundle

	echo "install_uninstall_juju-bundle
 has been installed"
	sleep 3
