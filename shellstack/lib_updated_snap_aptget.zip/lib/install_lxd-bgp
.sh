echo "Will now install install_lxd-bgp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lxd-bgp

	echo "install_lxd-bgp
 has been installed"
	sleep 3
