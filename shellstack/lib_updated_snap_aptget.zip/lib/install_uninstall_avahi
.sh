echo "Will now install install_uninstall_avahi
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install avahi

sudo snap remove avahi

	echo "install_uninstall_avahi
 has been installed"
	sleep 3
