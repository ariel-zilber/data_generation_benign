echo "Will now install install_flutter-calculator
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flutter-calculator

	echo "install_flutter-calculator
 has been installed"
	sleep 3
