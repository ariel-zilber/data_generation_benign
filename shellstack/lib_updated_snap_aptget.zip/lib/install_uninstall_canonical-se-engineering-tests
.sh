echo "Will now install install_uninstall_canonical-se-engineering-tests
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install canonical-se-engineering-tests

sudo snap remove canonical-se-engineering-tests

	echo "install_uninstall_canonical-se-engineering-tests
 has been installed"
	sleep 3
