echo "Will now install install_uninstall_drawio
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install drawio

sudo snap remove drawio

	echo "install_uninstall_drawio
 has been installed"
	sleep 3
