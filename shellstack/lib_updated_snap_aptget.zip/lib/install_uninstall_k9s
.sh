echo "Will now install install_uninstall_k9s
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install k9s

sudo snap remove k9s

	echo "install_uninstall_k9s
 has been installed"
	sleep 3
