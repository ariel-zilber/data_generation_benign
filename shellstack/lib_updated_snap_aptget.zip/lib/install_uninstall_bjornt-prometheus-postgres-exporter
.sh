echo "Will now install install_uninstall_bjornt-prometheus-postgres-exporter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bjornt-prometheus-postgres-exporter

sudo snap remove bjornt-prometheus-postgres-exporter

	echo "install_uninstall_bjornt-prometheus-postgres-exporter
 has been installed"
	sleep 3
