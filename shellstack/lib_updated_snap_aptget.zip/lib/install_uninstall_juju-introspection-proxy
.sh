echo "Will now install install_uninstall_juju-introspection-proxy
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install juju-introspection-proxy

sudo snap remove juju-introspection-proxy

	echo "install_uninstall_juju-introspection-proxy
 has been installed"
	sleep 3
