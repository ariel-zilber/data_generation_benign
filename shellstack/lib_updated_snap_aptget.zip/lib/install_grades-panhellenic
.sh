echo "Will now install install_grades-panhellenic
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install grades-panhellenic

	echo "install_grades-panhellenic
 has been installed"
	sleep 3
