echo "Will now install install_uninstall_ecpoint-pycal
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ecpoint-pycal

sudo snap remove ecpoint-pycal

	echo "install_uninstall_ecpoint-pycal
 has been installed"
	sleep 3
