echo "Will now install install_messenger-collabee
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install messenger-collabee

	echo "install_messenger-collabee
 has been installed"
	sleep 3
