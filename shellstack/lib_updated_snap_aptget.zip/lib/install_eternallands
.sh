echo "Will now install install_eternallands
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eternallands

	echo "install_eternallands
 has been installed"
	sleep 3
