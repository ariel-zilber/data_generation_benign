echo "Will now install install_uninstall_borhan
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install borhan

sudo snap remove borhan

	echo "install_uninstall_borhan
 has been installed"
	sleep 3
