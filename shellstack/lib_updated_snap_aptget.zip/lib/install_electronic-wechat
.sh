echo "Will now install install_electronic-wechat
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electronic-wechat

	echo "install_electronic-wechat
 has been installed"
	sleep 3
