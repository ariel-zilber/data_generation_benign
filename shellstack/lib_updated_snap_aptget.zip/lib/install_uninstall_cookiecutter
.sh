echo "Will now install install_uninstall_cookiecutter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cookiecutter

sudo snap remove cookiecutter

	echo "install_uninstall_cookiecutter
 has been installed"
	sleep 3
