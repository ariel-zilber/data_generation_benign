echo "Will now install install_uninstall_healthcheck-toolbox-example
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install healthcheck-toolbox-example

sudo snap remove healthcheck-toolbox-example

	echo "install_uninstall_healthcheck-toolbox-example
 has been installed"
	sleep 3
