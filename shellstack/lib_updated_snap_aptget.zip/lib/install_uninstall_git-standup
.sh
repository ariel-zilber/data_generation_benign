echo "Will now install install_uninstall_git-standup
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install git-standup

sudo snap remove git-standup

	echo "install_uninstall_git-standup
 has been installed"
	sleep 3
