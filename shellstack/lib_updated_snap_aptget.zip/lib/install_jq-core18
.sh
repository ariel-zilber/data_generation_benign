echo "Will now install install_jq-core18
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jq-core18

	echo "install_jq-core18
 has been installed"
	sleep 3
