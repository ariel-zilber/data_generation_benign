echo "Will now install install_uninstall_konquest
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install konquest

sudo snap remove konquest

	echo "install_uninstall_konquest
 has been installed"
	sleep 3
