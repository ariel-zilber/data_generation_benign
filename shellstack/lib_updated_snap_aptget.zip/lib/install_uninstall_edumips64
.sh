echo "Will now install install_uninstall_edumips64
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install edumips64

sudo snap remove edumips64

	echo "install_uninstall_edumips64
 has been installed"
	sleep 3
