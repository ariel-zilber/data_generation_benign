echo "Will now install install_dbtarzan
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dbtarzan

	echo "install_dbtarzan
 has been installed"
	sleep 3
