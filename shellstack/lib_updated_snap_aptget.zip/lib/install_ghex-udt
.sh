echo "Will now install install_ghex-udt
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ghex-udt

	echo "install_ghex-udt
 has been installed"
	sleep 3
