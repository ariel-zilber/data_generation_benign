echo "Will now install install_uninstall_magic-device-tool
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install magic-device-tool

sudo snap remove magic-device-tool

	echo "install_uninstall_magic-device-tool
 has been installed"
	sleep 3
