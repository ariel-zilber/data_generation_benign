echo "Will now install install_uninstall_mackup
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install mackup

sudo snap remove mackup

	echo "install_uninstall_mackup
 has been installed"
	sleep 3
