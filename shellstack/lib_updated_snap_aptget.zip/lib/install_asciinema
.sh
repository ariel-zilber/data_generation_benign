echo "Will now install install_asciinema
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install asciinema

	echo "install_asciinema
 has been installed"
	sleep 3
