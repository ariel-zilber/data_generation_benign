echo "Will now install install_uninstall_eraserix-3003-sensors
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eraserix-3003-sensors

sudo snap remove eraserix-3003-sensors

	echo "install_uninstall_eraserix-3003-sensors
 has been installed"
	sleep 3
