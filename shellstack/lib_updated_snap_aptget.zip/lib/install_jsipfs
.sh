echo "Will now install install_jsipfs
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jsipfs

	echo "install_jsipfs
 has been installed"
	sleep 3
