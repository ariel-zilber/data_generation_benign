echo "Will now install install_uninstall_hadoop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hadoop

sudo snap remove hadoop

	echo "install_uninstall_hadoop
 has been installed"
	sleep 3
