echo "Will now install install_uninstall_emoj
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install emoj

sudo snap remove emoj

	echo "install_uninstall_emoj
 has been installed"
	sleep 3
