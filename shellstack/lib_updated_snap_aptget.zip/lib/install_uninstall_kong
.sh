echo "Will now install install_uninstall_kong
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kong

sudo snap remove kong

	echo "install_uninstall_kong
 has been installed"
	sleep 3
