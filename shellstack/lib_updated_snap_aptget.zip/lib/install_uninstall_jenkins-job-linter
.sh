echo "Will now install install_uninstall_jenkins-job-linter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jenkins-job-linter

sudo snap remove jenkins-job-linter

	echo "install_uninstall_jenkins-job-linter
 has been installed"
	sleep 3
