echo "Will now install install_filebot
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install filebot

	echo "install_filebot
 has been installed"
	sleep 3
