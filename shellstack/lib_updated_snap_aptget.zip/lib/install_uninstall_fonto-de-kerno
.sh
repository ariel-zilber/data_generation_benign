echo "Will now install install_uninstall_fonto-de-kerno
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fonto-de-kerno

sudo snap remove fonto-de-kerno

	echo "install_uninstall_fonto-de-kerno
 has been installed"
	sleep 3
