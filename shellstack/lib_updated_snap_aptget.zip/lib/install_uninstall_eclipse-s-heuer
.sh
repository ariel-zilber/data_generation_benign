echo "Will now install install_uninstall_eclipse-s-heuer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eclipse-s-heuer

sudo snap remove eclipse-s-heuer

	echo "install_uninstall_eclipse-s-heuer
 has been installed"
	sleep 3
