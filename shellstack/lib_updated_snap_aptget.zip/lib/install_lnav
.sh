echo "Will now install install_lnav
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lnav

	echo "install_lnav
 has been installed"
	sleep 3
