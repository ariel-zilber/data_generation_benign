echo "Will now install install_uninstall_ammp-wifi-ap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ammp-wifi-ap

sudo snap remove ammp-wifi-ap

	echo "install_uninstall_ammp-wifi-ap
 has been installed"
	sleep 3
