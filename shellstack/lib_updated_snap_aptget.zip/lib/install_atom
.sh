echo "Will now install install_atom
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install atom

	echo "install_atom
 has been installed"
	sleep 3
