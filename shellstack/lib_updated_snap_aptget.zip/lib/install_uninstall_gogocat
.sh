echo "Will now install install_uninstall_gogocat
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gogocat

sudo snap remove gogocat

	echo "install_uninstall_gogocat
 has been installed"
	sleep 3
