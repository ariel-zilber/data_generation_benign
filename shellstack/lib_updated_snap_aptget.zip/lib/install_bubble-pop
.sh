echo "Will now install install_bubble-pop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bubble-pop

	echo "install_bubble-pop
 has been installed"
	sleep 3
