echo "Will now install install_icdiff
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install icdiff

	echo "install_icdiff
 has been installed"
	sleep 3
