echo "Will now install install_uninstall_jsonhttp2tcp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jsonhttp2tcp

sudo snap remove jsonhttp2tcp

	echo "install_uninstall_jsonhttp2tcp
 has been installed"
	sleep 3
