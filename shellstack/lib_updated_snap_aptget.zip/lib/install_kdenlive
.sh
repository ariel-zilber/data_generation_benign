echo "Will now install install_kdenlive
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kdenlive

	echo "install_kdenlive
 has been installed"
	sleep 3
