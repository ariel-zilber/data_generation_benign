echo "Will now install install_freeorion-agrrr3
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install freeorion-agrrr3

	echo "install_freeorion-agrrr3
 has been installed"
	sleep 3
