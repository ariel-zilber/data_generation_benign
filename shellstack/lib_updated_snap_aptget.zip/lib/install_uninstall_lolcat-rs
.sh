echo "Will now install install_uninstall_lolcat-rs
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lolcat-rs

sudo snap remove lolcat-rs

	echo "install_uninstall_lolcat-rs
 has been installed"
	sleep 3
