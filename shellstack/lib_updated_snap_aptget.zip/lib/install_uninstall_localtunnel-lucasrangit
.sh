echo "Will now install install_uninstall_localtunnel-lucasrangit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install localtunnel-lucasrangit

sudo snap remove localtunnel-lucasrangit

	echo "install_uninstall_localtunnel-lucasrangit
 has been installed"
	sleep 3
