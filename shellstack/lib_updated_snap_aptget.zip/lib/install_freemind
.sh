echo "Will now install install_freemind
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install freemind

	echo "install_freemind
 has been installed"
	sleep 3
