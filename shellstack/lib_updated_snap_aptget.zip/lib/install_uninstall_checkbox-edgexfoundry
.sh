echo "Will now install install_uninstall_checkbox-edgexfoundry
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox-edgexfoundry

sudo snap remove checkbox-edgexfoundry

	echo "install_uninstall_checkbox-edgexfoundry
 has been installed"
	sleep 3
