echo "Will now install install_uninstall_gobetween
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gobetween

sudo snap remove gobetween

	echo "install_uninstall_gobetween
 has been installed"
	sleep 3
