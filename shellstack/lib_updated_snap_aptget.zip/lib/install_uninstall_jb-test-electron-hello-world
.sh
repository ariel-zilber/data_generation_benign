echo "Will now install install_uninstall_jb-test-electron-hello-world
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jb-test-electron-hello-world

sudo snap remove jb-test-electron-hello-world

	echo "install_uninstall_jb-test-electron-hello-world
 has been installed"
	sleep 3
