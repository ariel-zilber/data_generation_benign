echo "Will now install install_uninstall_glate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install glate

sudo snap remove glate

	echo "install_uninstall_glate
 has been installed"
	sleep 3
