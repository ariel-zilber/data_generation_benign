echo "Will now install install_gnome-hitori
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-hitori

	echo "install_gnome-hitori
 has been installed"
	sleep 3
