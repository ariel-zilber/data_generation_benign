echo "Will now install install_uninstall_fortune-cm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fortune-cm

sudo snap remove fortune-cm

	echo "install_uninstall_fortune-cm
 has been installed"
	sleep 3
