echo "Will now install install_iota-mwc17
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iota-mwc17

	echo "install_iota-mwc17
 has been installed"
	sleep 3
