echo "Will now install install_uninstall_cactpot-solver
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cactpot-solver

sudo snap remove cactpot-solver

	echo "install_uninstall_cactpot-solver
 has been installed"
	sleep 3
