echo "Will now install install_jdtextedit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jdtextedit

	echo "install_jdtextedit
 has been installed"
	sleep 3
