echo "Will now install install_uninstall_jindosbox
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jindosbox

sudo snap remove jindosbox

	echo "install_uninstall_jindosbox
 has been installed"
	sleep 3
