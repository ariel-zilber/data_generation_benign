echo "Will now install install_kjelenak-snap2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kjelenak-snap2

	echo "install_kjelenak-snap2
 has been installed"
	sleep 3
