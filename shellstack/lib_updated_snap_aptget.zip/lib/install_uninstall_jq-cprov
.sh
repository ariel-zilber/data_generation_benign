echo "Will now install install_uninstall_jq-cprov
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jq-cprov

sudo snap remove jq-cprov

	echo "install_uninstall_jq-cprov
 has been installed"
	sleep 3
