echo "Will now install install_k9s
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install k9s

	echo "install_k9s
 has been installed"
	sleep 3
