echo "Will now install install_uninstall_jabref
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jabref

sudo snap remove jabref

	echo "install_uninstall_jabref
 has been installed"
	sleep 3
