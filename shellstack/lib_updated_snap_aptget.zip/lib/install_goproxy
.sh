echo "Will now install install_goproxy
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install goproxy

	echo "install_goproxy
 has been installed"
	sleep 3
