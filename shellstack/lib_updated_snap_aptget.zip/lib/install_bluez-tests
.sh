echo "Will now install install_bluez-tests
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bluez-tests

	echo "install_bluez-tests
 has been installed"
	sleep 3
