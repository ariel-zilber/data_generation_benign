echo "Will now install install_uninstall_djv
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install djv

sudo snap remove djv

	echo "install_uninstall_djv
 has been installed"
	sleep 3
