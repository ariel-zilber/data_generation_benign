echo "Will now install install_uninstall_j2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install j2

sudo snap remove j2

	echo "install_uninstall_j2
 has been installed"
	sleep 3
