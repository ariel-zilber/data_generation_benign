echo "Will now install install_uninstall_howdoi
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install howdoi

sudo snap remove howdoi

	echo "install_uninstall_howdoi
 has been installed"
	sleep 3
