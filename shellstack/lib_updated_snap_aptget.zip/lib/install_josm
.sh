echo "Will now install install_josm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install josm

	echo "install_josm
 has been installed"
	sleep 3
