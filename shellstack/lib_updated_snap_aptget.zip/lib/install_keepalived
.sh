echo "Will now install install_keepalived
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install keepalived

	echo "install_keepalived
 has been installed"
	sleep 3
