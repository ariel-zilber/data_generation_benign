echo "Will now install install_uninstall_libxslt
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install libxslt

sudo snap remove libxslt

	echo "install_uninstall_libxslt
 has been installed"
	sleep 3
