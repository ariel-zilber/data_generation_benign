echo "Will now install install_uninstall_0ad
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 0ad

sudo snap remove 0ad

	echo "install_uninstall_0ad
 has been installed"
	sleep 3
