echo "Will now install install_jenkins-carla
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jenkins-carla

	echo "install_jenkins-carla
 has been installed"
	sleep 3
