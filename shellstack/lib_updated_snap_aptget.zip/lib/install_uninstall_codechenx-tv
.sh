echo "Will now install install_uninstall_codechenx-tv
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install codechenx-tv

sudo snap remove codechenx-tv

	echo "install_uninstall_codechenx-tv
 has been installed"
	sleep 3
