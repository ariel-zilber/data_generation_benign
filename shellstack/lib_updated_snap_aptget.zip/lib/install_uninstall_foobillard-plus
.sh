echo "Will now install install_uninstall_foobillard-plus
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install foobillard-plus

sudo snap remove foobillard-plus

	echo "install_uninstall_foobillard-plus
 has been installed"
	sleep 3
