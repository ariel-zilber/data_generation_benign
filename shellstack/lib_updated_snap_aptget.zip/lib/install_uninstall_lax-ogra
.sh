echo "Will now install install_uninstall_lax-ogra
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lax-ogra

sudo snap remove lax-ogra

	echo "install_uninstall_lax-ogra
 has been installed"
	sleep 3
