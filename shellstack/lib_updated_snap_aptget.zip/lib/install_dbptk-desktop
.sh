echo "Will now install install_dbptk-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dbptk-desktop

	echo "install_dbptk-desktop
 has been installed"
	sleep 3
