echo "Will now install install_demo-amd64
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install demo-amd64

	echo "install_demo-amd64
 has been installed"
	sleep 3
