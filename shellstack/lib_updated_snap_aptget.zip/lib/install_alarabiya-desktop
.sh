echo "Will now install install_alarabiya-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install alarabiya-desktop

	echo "install_alarabiya-desktop
 has been installed"
	sleep 3
