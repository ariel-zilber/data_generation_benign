echo "Will now install install_uninstall_kesty-whatsapp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kesty-whatsapp

sudo snap remove kesty-whatsapp

	echo "install_uninstall_kesty-whatsapp
 has been installed"
	sleep 3
