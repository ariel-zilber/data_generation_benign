echo "Will now install install_amazon-ssm-agent
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install amazon-ssm-agent

	echo "install_amazon-ssm-agent
 has been installed"
	sleep 3
