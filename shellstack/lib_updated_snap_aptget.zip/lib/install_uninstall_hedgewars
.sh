echo "Will now install install_uninstall_hedgewars
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hedgewars

sudo snap remove hedgewars

	echo "install_uninstall_hedgewars
 has been installed"
	sleep 3
