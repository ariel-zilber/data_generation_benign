echo "Will now install install_uninstall_fennma-hello
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fennma-hello

sudo snap remove fennma-hello

	echo "install_uninstall_fennma-hello
 has been installed"
	sleep 3
