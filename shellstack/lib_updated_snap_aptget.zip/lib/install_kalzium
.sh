echo "Will now install install_kalzium
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kalzium

	echo "install_kalzium
 has been installed"
	sleep 3
