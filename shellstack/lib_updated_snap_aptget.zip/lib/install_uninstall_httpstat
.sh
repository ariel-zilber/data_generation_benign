echo "Will now install install_uninstall_httpstat
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install httpstat

sudo snap remove httpstat

	echo "install_uninstall_httpstat
 has been installed"
	sleep 3
