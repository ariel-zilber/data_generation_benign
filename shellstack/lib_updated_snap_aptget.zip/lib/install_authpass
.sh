echo "Will now install install_authpass
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install authpass

	echo "install_authpass
 has been installed"
	sleep 3
