echo "Will now install install_jotit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jotit

	echo "install_jotit
 has been installed"
	sleep 3
