echo "Will now install install_edgex-device-mqtt
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install edgex-device-mqtt

	echo "install_edgex-device-mqtt
 has been installed"
	sleep 3
