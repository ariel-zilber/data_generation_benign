echo "Will now install install_lithospos
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lithospos

	echo "install_lithospos
 has been installed"
	sleep 3
