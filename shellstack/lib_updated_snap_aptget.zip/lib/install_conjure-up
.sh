echo "Will now install install_conjure-up
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install conjure-up

	echo "install_conjure-up
 has been installed"
	sleep 3
