echo "Will now install install_kanagame
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kanagame

	echo "install_kanagame
 has been installed"
	sleep 3
