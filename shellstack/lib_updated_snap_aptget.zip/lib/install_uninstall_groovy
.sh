echo "Will now install install_uninstall_groovy
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install groovy

sudo snap remove groovy

	echo "install_uninstall_groovy
 has been installed"
	sleep 3
