echo "Will now install install_uninstall_e-mikrofirma
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install e-mikrofirma

sudo snap remove e-mikrofirma

	echo "install_uninstall_e-mikrofirma
 has been installed"
	sleep 3
