echo "Will now install install_uninstall_lci
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lci

sudo snap remove lci

	echo "install_uninstall_lci
 has been installed"
	sleep 3
