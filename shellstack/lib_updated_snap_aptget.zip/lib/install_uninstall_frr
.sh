echo "Will now install install_uninstall_frr
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install frr

sudo snap remove frr

	echo "install_uninstall_frr
 has been installed"
	sleep 3
