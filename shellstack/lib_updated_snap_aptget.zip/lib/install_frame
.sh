echo "Will now install install_frame
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install frame

	echo "install_frame
 has been installed"
	sleep 3
