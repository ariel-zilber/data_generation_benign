echo "Will now install install_uninstall_dukto
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dukto

sudo snap remove dukto

	echo "install_uninstall_dukto
 has been installed"
	sleep 3
