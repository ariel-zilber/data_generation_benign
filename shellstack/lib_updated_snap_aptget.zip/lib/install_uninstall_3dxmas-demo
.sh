echo "Will now install install_uninstall_3dxmas-demo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 3dxmas-demo

sudo snap remove 3dxmas-demo

	echo "install_uninstall_3dxmas-demo
 has been installed"
	sleep 3
