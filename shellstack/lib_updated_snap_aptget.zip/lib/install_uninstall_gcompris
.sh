echo "Will now install install_uninstall_gcompris
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gcompris

sudo snap remove gcompris

	echo "install_uninstall_gcompris
 has been installed"
	sleep 3
