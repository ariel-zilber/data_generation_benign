echo "Will now install install_uninstall_infiniti-clips
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install infiniti-clips

sudo snap remove infiniti-clips

	echo "install_uninstall_infiniti-clips
 has been installed"
	sleep 3
