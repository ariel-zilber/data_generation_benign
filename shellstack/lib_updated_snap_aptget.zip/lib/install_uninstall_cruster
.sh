echo "Will now install install_uninstall_cruster
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cruster

sudo snap remove cruster

	echo "install_uninstall_cruster
 has been installed"
	sleep 3
