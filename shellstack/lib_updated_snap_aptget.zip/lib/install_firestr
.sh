echo "Will now install install_firestr
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install firestr

	echo "install_firestr
 has been installed"
	sleep 3
