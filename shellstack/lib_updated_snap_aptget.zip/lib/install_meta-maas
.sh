echo "Will now install install_meta-maas
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install meta-maas

	echo "install_meta-maas
 has been installed"
	sleep 3
