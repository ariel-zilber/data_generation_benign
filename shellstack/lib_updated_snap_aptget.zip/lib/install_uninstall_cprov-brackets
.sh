echo "Will now install install_uninstall_cprov-brackets
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cprov-brackets

sudo snap remove cprov-brackets

	echo "install_uninstall_cprov-brackets
 has been installed"
	sleep 3
