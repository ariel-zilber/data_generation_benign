echo "Will now install install_uninstall_guoqingsnap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install guoqingsnap

sudo snap remove guoqingsnap

	echo "install_uninstall_guoqingsnap
 has been installed"
	sleep 3
