echo "Will now install install_uninstall_assemblyscript
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install assemblyscript

sudo snap remove assemblyscript

	echo "install_uninstall_assemblyscript
 has been installed"
	sleep 3
