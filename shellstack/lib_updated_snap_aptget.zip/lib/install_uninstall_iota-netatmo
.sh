echo "Will now install install_uninstall_iota-netatmo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iota-netatmo

sudo snap remove iota-netatmo

	echo "install_uninstall_iota-netatmo
 has been installed"
	sleep 3
