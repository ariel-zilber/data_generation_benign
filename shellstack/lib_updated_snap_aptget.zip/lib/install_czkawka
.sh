echo "Will now install install_czkawka
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install czkawka

	echo "install_czkawka
 has been installed"
	sleep 3
