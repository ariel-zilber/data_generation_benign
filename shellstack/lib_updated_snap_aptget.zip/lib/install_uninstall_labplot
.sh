echo "Will now install install_uninstall_labplot
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install labplot

sudo snap remove labplot

	echo "install_uninstall_labplot
 has been installed"
	sleep 3
