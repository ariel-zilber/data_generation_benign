echo "Will now install install_uninstall_electron-update-mechanism-example
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electron-update-mechanism-example

sudo snap remove electron-update-mechanism-example

	echo "install_uninstall_electron-update-mechanism-example
 has been installed"
	sleep 3
