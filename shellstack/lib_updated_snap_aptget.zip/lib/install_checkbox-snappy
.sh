echo "Will now install install_checkbox-snappy
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox-snappy

	echo "install_checkbox-snappy
 has been installed"
	sleep 3
