echo "Will now install install_uninstall_btctools
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install btctools

sudo snap remove btctools

	echo "install_uninstall_btctools
 has been installed"
	sleep 3
