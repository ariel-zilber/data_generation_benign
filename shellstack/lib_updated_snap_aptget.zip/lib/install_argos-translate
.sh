echo "Will now install install_argos-translate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install argos-translate

	echo "install_argos-translate
 has been installed"
	sleep 3
