echo "Will now install install_beaker-browser
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install beaker-browser

	echo "install_beaker-browser
 has been installed"
	sleep 3
