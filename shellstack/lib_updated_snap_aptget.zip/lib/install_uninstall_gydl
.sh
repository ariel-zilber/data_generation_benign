echo "Will now install install_uninstall_gydl
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gydl

sudo snap remove gydl

	echo "install_uninstall_gydl
 has been installed"
	sleep 3
