echo "Will now install install_kig
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kig

	echo "install_kig
 has been installed"
	sleep 3
