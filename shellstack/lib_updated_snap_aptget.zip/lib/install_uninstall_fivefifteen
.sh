echo "Will now install install_uninstall_fivefifteen
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fivefifteen

sudo snap remove fivefifteen

	echo "install_uninstall_fivefifteen
 has been installed"
	sleep 3
