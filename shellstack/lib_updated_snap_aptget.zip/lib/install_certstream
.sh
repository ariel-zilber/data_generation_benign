echo "Will now install install_certstream
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install certstream

	echo "install_certstream
 has been installed"
	sleep 3
