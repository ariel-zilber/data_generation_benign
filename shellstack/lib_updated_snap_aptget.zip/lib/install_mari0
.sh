echo "Will now install install_mari0
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install mari0

	echo "install_mari0
 has been installed"
	sleep 3
