echo "Will now install install_apple-music-for-linux
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install apple-music-for-linux

	echo "install_apple-music-for-linux
 has been installed"
	sleep 3
