echo "Will now install install_uninstall_autoskola-free6
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install autoskola-free6

sudo snap remove autoskola-free6

	echo "install_uninstall_autoskola-free6
 has been installed"
	sleep 3
