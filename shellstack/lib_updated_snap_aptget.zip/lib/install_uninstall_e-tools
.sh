echo "Will now install install_uninstall_e-tools
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install e-tools

sudo snap remove e-tools

	echo "install_uninstall_e-tools
 has been installed"
	sleep 3
