echo "Will now install install_uninstall_blender
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install blender

sudo snap remove blender

	echo "install_uninstall_blender
 has been installed"
	sleep 3
