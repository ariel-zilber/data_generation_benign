echo "Will now install install_uninstall_connectron
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install connectron

sudo snap remove connectron

	echo "install_uninstall_connectron
 has been installed"
	sleep 3
