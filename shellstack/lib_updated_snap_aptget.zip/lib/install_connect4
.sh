echo "Will now install install_connect4
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install connect4

	echo "install_connect4
 has been installed"
	sleep 3
