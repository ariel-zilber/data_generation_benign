echo "Will now install install_go-eth
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install go-eth

	echo "install_go-eth
 has been installed"
	sleep 3
