echo "Will now install install_cybear-jinni
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cybear-jinni

	echo "install_cybear-jinni
 has been installed"
	sleep 3
