echo "Will now install install_code
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install code

	echo "install_code
 has been installed"
	sleep 3
