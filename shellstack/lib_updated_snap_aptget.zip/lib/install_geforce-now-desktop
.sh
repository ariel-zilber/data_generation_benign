echo "Will now install install_geforce-now-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install geforce-now-desktop

	echo "install_geforce-now-desktop
 has been installed"
	sleep 3
