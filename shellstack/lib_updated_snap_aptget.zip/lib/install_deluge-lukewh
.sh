echo "Will now install install_deluge-lukewh
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install deluge-lukewh

	echo "install_deluge-lukewh
 has been installed"
	sleep 3
