echo "Will now install install_uninstall_bashfuscator
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bashfuscator

sudo snap remove bashfuscator

	echo "install_uninstall_bashfuscator
 has been installed"
	sleep 3
