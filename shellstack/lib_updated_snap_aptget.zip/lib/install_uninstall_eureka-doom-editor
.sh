echo "Will now install install_uninstall_eureka-doom-editor
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eureka-doom-editor

sudo snap remove eureka-doom-editor

	echo "install_uninstall_eureka-doom-editor
 has been installed"
	sleep 3
