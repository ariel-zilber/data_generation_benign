echo "Will now install install_magnesium
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install magnesium

	echo "install_magnesium
 has been installed"
	sleep 3
