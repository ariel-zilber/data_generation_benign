echo "Will now install install_conn-check
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install conn-check

	echo "install_conn-check
 has been installed"
	sleep 3
