echo "Will now install install_blr-says
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install blr-says

	echo "install_blr-says
 has been installed"
	sleep 3
