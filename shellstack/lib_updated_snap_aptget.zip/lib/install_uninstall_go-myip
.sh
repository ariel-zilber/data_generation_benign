echo "Will now install install_uninstall_go-myip
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install go-myip

sudo snap remove go-myip

	echo "install_uninstall_go-myip
 has been installed"
	sleep 3
