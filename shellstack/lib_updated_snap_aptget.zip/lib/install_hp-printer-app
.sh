echo "Will now install install_hp-printer-app
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hp-printer-app

	echo "install_hp-printer-app
 has been installed"
	sleep 3
