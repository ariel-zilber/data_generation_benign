echo "Will now install install_uninstall_kde-frameworks-5-qt-5-14-core18-sdk
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kde-frameworks-5-qt-5-14-core18-sdk

sudo snap remove kde-frameworks-5-qt-5-14-core18-sdk

	echo "install_uninstall_kde-frameworks-5-qt-5-14-core18-sdk
 has been installed"
	sleep 3
