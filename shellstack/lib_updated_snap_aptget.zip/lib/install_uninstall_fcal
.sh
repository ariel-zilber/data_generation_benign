echo "Will now install install_uninstall_fcal
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fcal

sudo snap remove fcal

	echo "install_uninstall_fcal
 has been installed"
	sleep 3
