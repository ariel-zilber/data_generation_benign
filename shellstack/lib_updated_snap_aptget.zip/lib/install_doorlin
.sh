echo "Will now install install_doorlin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install doorlin

	echo "install_doorlin
 has been installed"
	sleep 3
