echo "Will now install install_uninstall_authenticator
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install authenticator

sudo snap remove authenticator

	echo "install_uninstall_authenticator
 has been installed"
	sleep 3
