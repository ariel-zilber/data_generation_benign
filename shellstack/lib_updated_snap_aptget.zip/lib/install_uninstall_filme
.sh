echo "Will now install install_uninstall_filme
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install filme

sudo snap remove filme

	echo "install_uninstall_filme
 has been installed"
	sleep 3
