echo "Will now install install_ec
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ec

	echo "install_ec
 has been installed"
	sleep 3
