echo "Will now install install_midterm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install midterm

	echo "install_midterm
 has been installed"
	sleep 3
