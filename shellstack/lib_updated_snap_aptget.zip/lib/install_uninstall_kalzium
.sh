echo "Will now install install_uninstall_kalzium
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kalzium

sudo snap remove kalzium

	echo "install_uninstall_kalzium
 has been installed"
	sleep 3
