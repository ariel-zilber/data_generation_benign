echo "Will now install install_uninstall_branch-diff
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install branch-diff

sudo snap remove branch-diff

	echo "install_uninstall_branch-diff
 has been installed"
	sleep 3
