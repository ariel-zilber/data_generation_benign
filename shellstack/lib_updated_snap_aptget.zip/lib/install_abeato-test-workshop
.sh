echo "Will now install install_abeato-test-workshop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install abeato-test-workshop

	echo "install_abeato-test-workshop
 has been installed"
	sleep 3
