echo "Will now install install_cookie-clicker
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cookie-clicker

	echo "install_cookie-clicker
 has been installed"
	sleep 3
