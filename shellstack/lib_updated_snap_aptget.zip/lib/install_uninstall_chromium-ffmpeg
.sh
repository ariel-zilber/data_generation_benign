echo "Will now install install_uninstall_chromium-ffmpeg
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install chromium-ffmpeg

sudo snap remove chromium-ffmpeg

	echo "install_uninstall_chromium-ffmpeg
 has been installed"
	sleep 3
