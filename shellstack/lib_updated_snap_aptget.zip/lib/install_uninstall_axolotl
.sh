echo "Will now install install_uninstall_axolotl
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install axolotl

sudo snap remove axolotl

	echo "install_uninstall_axolotl
 has been installed"
	sleep 3
