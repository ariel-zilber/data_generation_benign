echo "Will now install install_uninstall_balls2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install balls2

sudo snap remove balls2

	echo "install_uninstall_balls2
 has been installed"
	sleep 3
