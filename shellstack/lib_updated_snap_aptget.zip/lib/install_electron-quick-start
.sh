echo "Will now install install_electron-quick-start
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electron-quick-start

	echo "install_electron-quick-start
 has been installed"
	sleep 3
