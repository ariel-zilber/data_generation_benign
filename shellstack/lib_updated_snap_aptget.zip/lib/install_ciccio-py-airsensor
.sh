echo "Will now install install_ciccio-py-airsensor
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ciccio-py-airsensor

	echo "install_ciccio-py-airsensor
 has been installed"
	sleep 3
