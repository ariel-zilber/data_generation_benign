echo "Will now install install_uninstall_kgraphviewer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kgraphviewer

sudo snap remove kgraphviewer

	echo "install_uninstall_kgraphviewer
 has been installed"
	sleep 3
