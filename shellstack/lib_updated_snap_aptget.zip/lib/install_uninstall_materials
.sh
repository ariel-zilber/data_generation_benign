echo "Will now install install_uninstall_materials
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install materials

sudo snap remove materials

	echo "install_uninstall_materials
 has been installed"
	sleep 3
