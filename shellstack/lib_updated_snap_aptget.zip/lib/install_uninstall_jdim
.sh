echo "Will now install install_uninstall_jdim
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jdim

sudo snap remove jdim

	echo "install_uninstall_jdim
 has been installed"
	sleep 3
