echo "Will now install install_uninstall_appx
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install appx

sudo snap remove appx

	echo "install_uninstall_appx
 has been installed"
	sleep 3
