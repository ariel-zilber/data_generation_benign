echo "Will now install install_uninstall_gifcurry
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gifcurry

sudo snap remove gifcurry

	echo "install_uninstall_gifcurry
 has been installed"
	sleep 3
