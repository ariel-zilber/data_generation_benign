echo "Will now install install_uninstall_irssi
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install irssi

sudo snap remove irssi

	echo "install_uninstall_irssi
 has been installed"
	sleep 3
