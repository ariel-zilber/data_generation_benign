echo "Will now install install_uninstall_dnslookup
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dnslookup

sudo snap remove dnslookup

	echo "install_uninstall_dnslookup
 has been installed"
	sleep 3
