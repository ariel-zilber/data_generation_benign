echo "Will now install install_uninstall_jira-to-tripletex
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jira-to-tripletex

sudo snap remove jira-to-tripletex

	echo "install_uninstall_jira-to-tripletex
 has been installed"
	sleep 3
