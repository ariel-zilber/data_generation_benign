echo "Will now install install_bashtop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bashtop

	echo "install_bashtop
 has been installed"
	sleep 3
