echo "Will now install install_dosbox-jz
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dosbox-jz

	echo "install_dosbox-jz
 has been installed"
	sleep 3
