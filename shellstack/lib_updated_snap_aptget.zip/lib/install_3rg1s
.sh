echo "Will now install install_3rg1s
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 3rg1s

	echo "install_3rg1s
 has been installed"
	sleep 3
