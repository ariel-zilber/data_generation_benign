echo "Will now install install_gobot-blink-elopio
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gobot-blink-elopio

	echo "install_gobot-blink-elopio
 has been installed"
	sleep 3
