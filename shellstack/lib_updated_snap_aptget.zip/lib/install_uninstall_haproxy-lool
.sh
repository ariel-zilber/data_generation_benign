echo "Will now install install_uninstall_haproxy-lool
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install haproxy-lool

sudo snap remove haproxy-lool

	echo "install_uninstall_haproxy-lool
 has been installed"
	sleep 3
