echo "Will now install install_uninstall_bcrypt-tool
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bcrypt-tool

sudo snap remove bcrypt-tool

	echo "install_uninstall_bcrypt-tool
 has been installed"
	sleep 3
