echo "Will now install install_jupyter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jupyter

	echo "install_jupyter
 has been installed"
	sleep 3
