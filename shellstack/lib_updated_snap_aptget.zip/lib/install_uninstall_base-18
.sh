echo "Will now install install_uninstall_base-18
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install base-18

sudo snap remove base-18

	echo "install_uninstall_base-18
 has been installed"
	sleep 3
