echo "Will now install install_lainan-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lainan-desktop

	echo "install_lainan-desktop
 has been installed"
	sleep 3
