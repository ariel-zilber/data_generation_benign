echo "Will now install install_uninstall_canonical-livepatch
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install canonical-livepatch

sudo snap remove canonical-livepatch

	echo "install_uninstall_canonical-livepatch
 has been installed"
	sleep 3
