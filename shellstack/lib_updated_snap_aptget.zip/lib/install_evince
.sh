echo "Will now install install_evince
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install evince

	echo "install_evince
 has been installed"
	sleep 3
