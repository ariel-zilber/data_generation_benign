echo "Will now install install_uninstall_kominal-connect
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kominal-connect

sudo snap remove kominal-connect

	echo "install_uninstall_kominal-connect
 has been installed"
	sleep 3
