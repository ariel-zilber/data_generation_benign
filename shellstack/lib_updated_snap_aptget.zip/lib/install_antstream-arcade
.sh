echo "Will now install install_antstream-arcade
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install antstream-arcade

	echo "install_antstream-arcade
 has been installed"
	sleep 3
