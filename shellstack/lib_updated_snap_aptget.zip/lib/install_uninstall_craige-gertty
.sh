echo "Will now install install_uninstall_craige-gertty
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install craige-gertty

sudo snap remove craige-gertty

	echo "install_uninstall_craige-gertty
 has been installed"
	sleep 3
