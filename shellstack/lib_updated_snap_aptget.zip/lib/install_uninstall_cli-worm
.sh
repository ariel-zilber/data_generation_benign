echo "Will now install install_uninstall_cli-worm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cli-worm

sudo snap remove cli-worm

	echo "install_uninstall_cli-worm
 has been installed"
	sleep 3
