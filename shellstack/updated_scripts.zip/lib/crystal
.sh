
	echo "Will now install crystal
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install crystal

	echo "crystal
 has been installed"
	sleep 3
