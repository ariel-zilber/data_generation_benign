
	echo "Will now install kdiamond
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kdiamond

	echo "kdiamond
 has been installed"
	sleep 3
