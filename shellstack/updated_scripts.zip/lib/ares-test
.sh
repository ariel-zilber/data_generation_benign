
	echo "Will now install ares-test
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ares-test

	echo "ares-test
 has been installed"
	sleep 3
