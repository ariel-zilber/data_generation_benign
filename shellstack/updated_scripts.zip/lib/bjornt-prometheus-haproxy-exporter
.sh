
	echo "Will now install bjornt-prometheus-haproxy-exporter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bjornt-prometheus-haproxy-exporter

	echo "bjornt-prometheus-haproxy-exporter
 has been installed"
	sleep 3
