
	echo "Will now install krop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install krop

	echo "krop
 has been installed"
	sleep 3
