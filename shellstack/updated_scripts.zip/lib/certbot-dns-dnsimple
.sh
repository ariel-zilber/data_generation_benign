
	echo "Will now install certbot-dns-dnsimple
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install certbot-dns-dnsimple

	echo "certbot-dns-dnsimple
 has been installed"
	sleep 3
