
	echo "Will now install halo-weather
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install halo-weather

	echo "halo-weather
 has been installed"
	sleep 3
