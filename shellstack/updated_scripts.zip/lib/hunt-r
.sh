
	echo "Will now install hunt-r
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hunt-r

	echo "hunt-r
 has been installed"
	sleep 3
