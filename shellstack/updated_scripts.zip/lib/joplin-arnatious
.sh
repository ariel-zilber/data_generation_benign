
	echo "Will now install joplin-arnatious
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install joplin-arnatious

	echo "joplin-arnatious
 has been installed"
	sleep 3
