
	echo "Will now install enpass
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install enpass

	echo "enpass
 has been installed"
	sleep 3
