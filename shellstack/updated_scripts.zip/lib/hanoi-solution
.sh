
	echo "Will now install hanoi-solution
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hanoi-solution

	echo "hanoi-solution
 has been installed"
	sleep 3
