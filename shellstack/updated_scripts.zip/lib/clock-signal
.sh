
	echo "Will now install clock-signal
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install clock-signal

	echo "clock-signal
 has been installed"
	sleep 3
