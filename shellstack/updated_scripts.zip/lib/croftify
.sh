
	echo "Will now install croftify
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install croftify

	echo "croftify
 has been installed"
	sleep 3
