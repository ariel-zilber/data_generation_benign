
	echo "Will now install kde-frameworks-5-qt-5-15-core20
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kde-frameworks-5-qt-5-15-core20

	echo "kde-frameworks-5-qt-5-15-core20
 has been installed"
	sleep 3
