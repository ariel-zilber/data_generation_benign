
	echo "Will now install heads-tails
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install heads-tails

	echo "heads-tails
 has been installed"
	sleep 3
