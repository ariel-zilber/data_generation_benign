
	echo "Will now install certbot-dns-gehirn
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install certbot-dns-gehirn

	echo "certbot-dns-gehirn
 has been installed"
	sleep 3
