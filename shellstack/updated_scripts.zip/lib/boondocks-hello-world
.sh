
	echo "Will now install boondocks-hello-world
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install boondocks-hello-world

	echo "boondocks-hello-world
 has been installed"
	sleep 3
