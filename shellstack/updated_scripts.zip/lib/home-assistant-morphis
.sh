
	echo "Will now install home-assistant-morphis
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install home-assistant-morphis

	echo "home-assistant-morphis
 has been installed"
	sleep 3
