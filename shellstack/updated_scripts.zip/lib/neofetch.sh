function easy_install_neofetch {
	echo "Will now install neofetch"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt install snapd
sudo snap install neofetch --beta
	echo "neofetch has been installed"
	sleep 3
}