
	echo "Will now install jsonhttp2tcp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jsonhttp2tcp

	echo "jsonhttp2tcp
 has been installed"
	sleep 3
