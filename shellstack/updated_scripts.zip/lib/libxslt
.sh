
	echo "Will now install libxslt
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install libxslt

	echo "libxslt
 has been installed"
	sleep 3
