
	echo "Will now install kde-frameworks-5-core18
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kde-frameworks-5-core18

	echo "kde-frameworks-5-core18
 has been installed"
	sleep 3
