
	echo "Will now install aria2c
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install aria2c

	echo "aria2c
 has been installed"
	sleep 3
