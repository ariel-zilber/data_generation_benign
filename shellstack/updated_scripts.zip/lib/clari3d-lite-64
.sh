
	echo "Will now install clari3d-lite-64
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install clari3d-lite-64

	echo "clari3d-lite-64
 has been installed"
	sleep 3
