
	echo "Will now install liko-12
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install liko-12

	echo "liko-12
 has been installed"
	sleep 3
