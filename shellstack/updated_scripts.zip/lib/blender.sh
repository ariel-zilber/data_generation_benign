function easy_install_blender {
	echo "Will now install blender"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt install snapd
sudo snap install blender --classic
	echo "blender has been installed"
	sleep 3
}