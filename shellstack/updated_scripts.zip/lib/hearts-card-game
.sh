
	echo "Will now install hearts-card-game
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hearts-card-game

	echo "hearts-card-game
 has been installed"
	sleep 3
