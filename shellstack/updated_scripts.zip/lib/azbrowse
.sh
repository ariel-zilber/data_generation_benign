
	echo "Will now install azbrowse
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install azbrowse

	echo "azbrowse
 has been installed"
	sleep 3
