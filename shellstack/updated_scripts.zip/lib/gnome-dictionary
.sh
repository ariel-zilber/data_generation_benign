
	echo "Will now install gnome-dictionary
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-dictionary

	echo "gnome-dictionary
 has been installed"
	sleep 3
