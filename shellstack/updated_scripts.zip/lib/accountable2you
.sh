
	echo "Will now install accountable2you
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install accountable2you

	echo "accountable2you
 has been installed"
	sleep 3
