
	echo "Will now install instagraph
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install instagraph

	echo "instagraph
 has been installed"
	sleep 3
