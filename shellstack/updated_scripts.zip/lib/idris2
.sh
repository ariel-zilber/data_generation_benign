
	echo "Will now install idris2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install idris2

	echo "idris2
 has been installed"
	sleep 3
