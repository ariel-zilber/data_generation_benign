
	echo "Will now install fontvuer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fontvuer

	echo "fontvuer
 has been installed"
	sleep 3
