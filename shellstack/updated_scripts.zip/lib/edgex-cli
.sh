
	echo "Will now install edgex-cli
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install edgex-cli

	echo "edgex-cli
 has been installed"
	sleep 3
