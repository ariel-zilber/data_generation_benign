
	echo "Will now install 1password-linux
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 1password-linux

	echo "1password-linux
 has been installed"
	sleep 3
