
	echo "Will now install falkon
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install falkon

	echo "falkon
 has been installed"
	sleep 3
