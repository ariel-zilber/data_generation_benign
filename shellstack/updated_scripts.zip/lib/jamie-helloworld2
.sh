
	echo "Will now install jamie-helloworld2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jamie-helloworld2

	echo "jamie-helloworld2
 has been installed"
	sleep 3
