
	echo "Will now install cat-say
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cat-say

	echo "cat-say
 has been installed"
	sleep 3
