
	echo "Will now install imgpress
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install imgpress

	echo "imgpress
 has been installed"
	sleep 3
