
	echo "Will now install dlna-downloader
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dlna-downloader

	echo "dlna-downloader
 has been installed"
	sleep 3
