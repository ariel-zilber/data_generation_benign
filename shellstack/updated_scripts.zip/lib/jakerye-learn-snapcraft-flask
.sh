
	echo "Will now install jakerye-learn-snapcraft-flask
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jakerye-learn-snapcraft-flask

	echo "jakerye-learn-snapcraft-flask
 has been installed"
	sleep 3
