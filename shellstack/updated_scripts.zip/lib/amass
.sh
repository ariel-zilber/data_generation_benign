
	echo "Will now install amass
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install amass

	echo "amass
 has been installed"
	sleep 3
