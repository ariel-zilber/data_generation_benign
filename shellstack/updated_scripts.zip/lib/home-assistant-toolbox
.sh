
	echo "Will now install home-assistant-toolbox
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install home-assistant-toolbox

	echo "home-assistant-toolbox
 has been installed"
	sleep 3
