
	echo "Will now install learnit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install learnit

	echo "learnit
 has been installed"
	sleep 3
