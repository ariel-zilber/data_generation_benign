
	echo "Will now install abeato-test-content-plug-to-classic
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install abeato-test-content-plug-to-classic

	echo "abeato-test-content-plug-to-classic
 has been installed"
	sleep 3
