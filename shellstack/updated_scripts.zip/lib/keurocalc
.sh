
	echo "Will now install keurocalc
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install keurocalc

	echo "keurocalc
 has been installed"
	sleep 3
