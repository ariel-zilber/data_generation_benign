
	echo "Will now install agsubsim
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install agsubsim

	echo "agsubsim
 has been installed"
	sleep 3
