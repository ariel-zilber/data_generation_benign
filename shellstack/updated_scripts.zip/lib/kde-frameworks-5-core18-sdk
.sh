
	echo "Will now install kde-frameworks-5-core18-sdk
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kde-frameworks-5-core18-sdk

	echo "kde-frameworks-5-core18-sdk
 has been installed"
	sleep 3
