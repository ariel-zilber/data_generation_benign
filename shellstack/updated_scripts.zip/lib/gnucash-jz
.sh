
	echo "Will now install gnucash-jz
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnucash-jz

	echo "gnucash-jz
 has been installed"
	sleep 3
