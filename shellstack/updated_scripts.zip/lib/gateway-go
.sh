
	echo "Will now install gateway-go
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gateway-go

	echo "gateway-go
 has been installed"
	sleep 3
