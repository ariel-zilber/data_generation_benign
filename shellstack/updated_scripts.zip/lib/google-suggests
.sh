
	echo "Will now install google-suggests
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install google-suggests

	echo "google-suggests
 has been installed"
	sleep 3
