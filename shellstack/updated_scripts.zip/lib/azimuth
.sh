
	echo "Will now install azimuth
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install azimuth

	echo "azimuth
 has been installed"
	sleep 3
