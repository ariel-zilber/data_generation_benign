
	echo "Will now install geforce-now-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install geforce-now-desktop

	echo "geforce-now-desktop
 has been installed"
	sleep 3
