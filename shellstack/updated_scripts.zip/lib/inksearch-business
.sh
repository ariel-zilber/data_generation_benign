
	echo "Will now install inksearch-business
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install inksearch-business

	echo "inksearch-business
 has been installed"
	sleep 3
