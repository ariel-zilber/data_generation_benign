
	echo "Will now install boxy-svg
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install boxy-svg

	echo "boxy-svg
 has been installed"
	sleep 3
