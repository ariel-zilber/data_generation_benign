
	echo "Will now install jjo-vegeta
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jjo-vegeta

	echo "jjo-vegeta
 has been installed"
	sleep 3
