
	echo "Will now install ket
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ket

	echo "ket
 has been installed"
	sleep 3
