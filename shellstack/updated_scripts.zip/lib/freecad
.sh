
	echo "Will now install freecad
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install freecad

	echo "freecad
 has been installed"
	sleep 3
