
	echo "Will now install gnome-sudoku
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-sudoku

	echo "gnome-sudoku
 has been installed"
	sleep 3
