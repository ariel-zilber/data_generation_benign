
	echo "Will now install jenkins-job-linter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jenkins-job-linter

	echo "jenkins-job-linter
 has been installed"
	sleep 3
