
	echo "Will now install asa-ncmpcpp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install asa-ncmpcpp

	echo "asa-ncmpcpp
 has been installed"
	sleep 3
