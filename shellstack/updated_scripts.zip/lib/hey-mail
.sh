
	echo "Will now install hey-mail
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hey-mail

	echo "hey-mail
 has been installed"
	sleep 3
