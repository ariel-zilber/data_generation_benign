
	echo "Will now install languagetool
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install languagetool

	echo "languagetool
 has been installed"
	sleep 3
