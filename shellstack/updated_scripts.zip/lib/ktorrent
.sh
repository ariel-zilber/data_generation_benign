
	echo "Will now install ktorrent
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ktorrent

	echo "ktorrent
 has been installed"
	sleep 3
