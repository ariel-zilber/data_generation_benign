
	echo "Will now install i2pd
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install i2pd

	echo "i2pd
 has been installed"
	sleep 3
