
	echo "Will now install kteatime
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kteatime

	echo "kteatime
 has been installed"
	sleep 3
