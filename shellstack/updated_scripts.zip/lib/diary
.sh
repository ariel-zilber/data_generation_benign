
	echo "Will now install diary
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install diary

	echo "diary
 has been installed"
	sleep 3
