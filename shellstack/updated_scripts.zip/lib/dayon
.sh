
	echo "Will now install dayon
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dayon

	echo "dayon
 has been installed"
	sleep 3
