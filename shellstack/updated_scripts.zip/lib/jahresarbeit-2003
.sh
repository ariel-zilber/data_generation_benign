
	echo "Will now install jahresarbeit-2003
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jahresarbeit-2003

	echo "jahresarbeit-2003
 has been installed"
	sleep 3
