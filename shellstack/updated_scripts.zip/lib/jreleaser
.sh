
	echo "Will now install jreleaser
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jreleaser

	echo "jreleaser
 has been installed"
	sleep 3
