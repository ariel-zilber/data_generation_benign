
	echo "Will now install autoskola-free6
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install autoskola-free6

	echo "autoskola-free6
 has been installed"
	sleep 3
