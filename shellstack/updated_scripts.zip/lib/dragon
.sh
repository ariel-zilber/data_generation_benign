
	echo "Will now install dragon
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dragon

	echo "dragon
 has been installed"
	sleep 3
