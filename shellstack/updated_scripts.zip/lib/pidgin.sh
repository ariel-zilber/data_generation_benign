function easy_install_pidgin {
	echo "Will now install pidgin"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt-get install pidgin
	echo "pidgin has been installed"
	sleep 3
}