
	echo "Will now install libxml2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install libxml2

	echo "libxml2
 has been installed"
	sleep 3
