
	echo "Will now install asm2go
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install asm2go

	echo "asm2go
 has been installed"
	sleep 3
