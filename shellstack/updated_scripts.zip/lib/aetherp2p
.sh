
	echo "Will now install aetherp2p
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install aetherp2p

	echo "aetherp2p
 has been installed"
	sleep 3
