
	echo "Will now install inoxision-monitoring
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install inoxision-monitoring

	echo "inoxision-monitoring
 has been installed"
	sleep 3
