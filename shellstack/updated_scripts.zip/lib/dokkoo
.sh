
	echo "Will now install dokkoo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dokkoo

	echo "dokkoo
 has been installed"
	sleep 3
