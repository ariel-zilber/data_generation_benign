
	echo "Will now install gamblify-verifier
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gamblify-verifier

	echo "gamblify-verifier
 has been installed"
	sleep 3
