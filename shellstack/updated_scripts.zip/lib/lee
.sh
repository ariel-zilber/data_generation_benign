
	echo "Will now install lee
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lee

	echo "lee
 has been installed"
	sleep 3
