
	echo "Will now install ciccio-py-airsensor
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ciccio-py-airsensor

	echo "ciccio-py-airsensor
 has been installed"
	sleep 3
