
	echo "Will now install downbook
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install downbook

	echo "downbook
 has been installed"
	sleep 3
