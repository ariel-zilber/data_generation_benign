
	echo "Will now install beaker-browser
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install beaker-browser

	echo "beaker-browser
 has been installed"
	sleep 3
