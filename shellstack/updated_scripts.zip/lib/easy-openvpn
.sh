
	echo "Will now install easy-openvpn
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install easy-openvpn

	echo "easy-openvpn
 has been installed"
	sleep 3
