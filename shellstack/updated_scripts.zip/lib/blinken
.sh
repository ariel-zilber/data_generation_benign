
	echo "Will now install blinken
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install blinken

	echo "blinken
 has been installed"
	sleep 3
