
	echo "Will now install airsonic
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install airsonic

	echo "airsonic
 has been installed"
	sleep 3
