
	echo "Will now install aws-iot-greengrass
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install aws-iot-greengrass

	echo "aws-iot-greengrass
 has been installed"
	sleep 3
