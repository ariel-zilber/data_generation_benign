
	echo "Will now install git-machete
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install git-machete

	echo "git-machete
 has been installed"
	sleep 3
