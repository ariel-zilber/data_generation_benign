
	echo "Will now install harsh
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install harsh

	echo "harsh
 has been installed"
	sleep 3
