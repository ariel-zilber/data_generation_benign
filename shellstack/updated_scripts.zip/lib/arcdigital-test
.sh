
	echo "Will now install arcdigital-test
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install arcdigital-test

	echo "arcdigital-test
 has been installed"
	sleep 3
