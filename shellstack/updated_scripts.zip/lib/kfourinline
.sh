
	echo "Will now install kfourinline
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kfourinline

	echo "kfourinline
 has been installed"
	sleep 3
