function easy_install_snapd {
	echo "Will now install snapd"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt install snapd
sudo snap install code --classic
	echo "snapd has been installed"
	sleep 3
}