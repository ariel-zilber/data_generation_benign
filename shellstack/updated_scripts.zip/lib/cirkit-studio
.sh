
	echo "Will now install cirkit-studio
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cirkit-studio

	echo "cirkit-studio
 has been installed"
	sleep 3
