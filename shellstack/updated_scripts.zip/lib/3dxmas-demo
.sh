
	echo "Will now install 3dxmas-demo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 3dxmas-demo

	echo "3dxmas-demo
 has been installed"
	sleep 3
