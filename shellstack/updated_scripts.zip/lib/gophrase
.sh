
	echo "Will now install gophrase
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gophrase

	echo "gophrase
 has been installed"
	sleep 3
