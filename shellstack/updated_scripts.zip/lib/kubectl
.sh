
	echo "Will now install kubectl
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kubectl

	echo "kubectl
 has been installed"
	sleep 3
