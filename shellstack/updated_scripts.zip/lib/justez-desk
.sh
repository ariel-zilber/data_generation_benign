
	echo "Will now install justez-desk
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install justez-desk

	echo "justez-desk
 has been installed"
	sleep 3
