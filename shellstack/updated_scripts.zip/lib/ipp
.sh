
	echo "Will now install ipp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ipp

	echo "ipp
 has been installed"
	sleep 3
