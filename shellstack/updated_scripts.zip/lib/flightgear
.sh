
	echo "Will now install flightgear
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flightgear

	echo "flightgear
 has been installed"
	sleep 3
