
	echo "Will now install hallo-carol
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hallo-carol

	echo "hallo-carol
 has been installed"
	sleep 3
