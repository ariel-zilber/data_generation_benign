
	echo "Will now install icedrive
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install icedrive

	echo "icedrive
 has been installed"
	sleep 3
