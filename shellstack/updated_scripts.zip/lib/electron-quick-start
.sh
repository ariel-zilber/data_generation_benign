
	echo "Will now install electron-quick-start
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electron-quick-start

	echo "electron-quick-start
 has been installed"
	sleep 3
