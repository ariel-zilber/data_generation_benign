
	echo "Will now install gigi2
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gigi2

	echo "gigi2
 has been installed"
	sleep 3
