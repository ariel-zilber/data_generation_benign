
	echo "Will now install ao
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ao

	echo "ao
 has been installed"
	sleep 3
