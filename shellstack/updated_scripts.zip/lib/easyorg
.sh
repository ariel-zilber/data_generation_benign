
	echo "Will now install easyorg
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install easyorg

	echo "easyorg
 has been installed"
	sleep 3
