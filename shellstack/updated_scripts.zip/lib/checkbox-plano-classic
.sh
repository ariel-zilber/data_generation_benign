
	echo "Will now install checkbox-plano-classic
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox-plano-classic

	echo "checkbox-plano-classic
 has been installed"
	sleep 3
