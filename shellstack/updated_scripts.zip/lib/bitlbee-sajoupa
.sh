
	echo "Will now install bitlbee-sajoupa
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bitlbee-sajoupa

	echo "bitlbee-sajoupa
 has been installed"
	sleep 3
