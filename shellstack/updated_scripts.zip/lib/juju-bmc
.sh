
	echo "Will now install juju-bmc
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install juju-bmc

	echo "juju-bmc
 has been installed"
	sleep 3
