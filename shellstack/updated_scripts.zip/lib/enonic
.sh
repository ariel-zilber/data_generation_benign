
	echo "Will now install enonic
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install enonic

	echo "enonic
 has been installed"
	sleep 3
