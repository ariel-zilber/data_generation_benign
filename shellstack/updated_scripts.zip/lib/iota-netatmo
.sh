
	echo "Will now install iota-netatmo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iota-netatmo

	echo "iota-netatmo
 has been installed"
	sleep 3
