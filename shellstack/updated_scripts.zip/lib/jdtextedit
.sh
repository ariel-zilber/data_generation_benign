
	echo "Will now install jdtextedit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jdtextedit

	echo "jdtextedit
 has been installed"
	sleep 3
