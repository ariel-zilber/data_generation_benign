
	echo "Will now install gnome-logs
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-logs

	echo "gnome-logs
 has been installed"
	sleep 3
