
	echo "Will now install jami-gnome
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jami-gnome

	echo "jami-gnome
 has been installed"
	sleep 3
