
	echo "Will now install cjp256-hello-strict
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cjp256-hello-strict

	echo "cjp256-hello-strict
 has been installed"
	sleep 3
