
	echo "Will now install frr
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install frr

	echo "frr
 has been installed"
	sleep 3
