
	echo "Will now install hanoi-towers
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hanoi-towers

	echo "hanoi-towers
 has been installed"
	sleep 3
