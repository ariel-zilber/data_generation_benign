
	echo "Will now install kesty-whatsapp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kesty-whatsapp

	echo "kesty-whatsapp
 has been installed"
	sleep 3
