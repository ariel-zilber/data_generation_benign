
	echo "Will now install clementine
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install clementine

	echo "clementine
 has been installed"
	sleep 3
