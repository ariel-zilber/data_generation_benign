
	echo "Will now install led01
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install led01

	echo "led01
 has been installed"
	sleep 3
