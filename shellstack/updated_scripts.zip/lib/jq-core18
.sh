
	echo "Will now install jq-core18
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jq-core18

	echo "jq-core18
 has been installed"
	sleep 3
