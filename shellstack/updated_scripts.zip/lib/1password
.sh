
	echo "Will now install 1password
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install 1password

	echo "1password
 has been installed"
	sleep 3
