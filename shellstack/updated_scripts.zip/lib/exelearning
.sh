
	echo "Will now install exelearning
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install exelearning

	echo "exelearning
 has been installed"
	sleep 3
