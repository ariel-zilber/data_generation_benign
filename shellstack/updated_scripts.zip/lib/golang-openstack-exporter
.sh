
	echo "Will now install golang-openstack-exporter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install golang-openstack-exporter

	echo "golang-openstack-exporter
 has been installed"
	sleep 3
