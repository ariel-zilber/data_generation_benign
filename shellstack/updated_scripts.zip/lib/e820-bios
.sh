
	echo "Will now install e820-bios
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install e820-bios

	echo "e820-bios
 has been installed"
	sleep 3
