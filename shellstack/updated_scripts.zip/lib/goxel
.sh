
	echo "Will now install goxel
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install goxel

	echo "goxel
 has been installed"
	sleep 3
