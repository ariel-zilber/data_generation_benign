
	echo "Will now install hexyl
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hexyl

	echo "hexyl
 has been installed"
	sleep 3
