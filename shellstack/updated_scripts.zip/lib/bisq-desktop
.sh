
	echo "Will now install bisq-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bisq-desktop

	echo "bisq-desktop
 has been installed"
	sleep 3
