
	echo "Will now install juju-crashdump
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install juju-crashdump

	echo "juju-crashdump
 has been installed"
	sleep 3
