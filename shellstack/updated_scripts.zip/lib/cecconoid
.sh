
	echo "Will now install cecconoid
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cecconoid

	echo "cecconoid
 has been installed"
	sleep 3
