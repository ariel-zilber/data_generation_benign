
	echo "Will now install cruster
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cruster

	echo "cruster
 has been installed"
	sleep 3
