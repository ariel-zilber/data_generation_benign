
	echo "Will now install codechenx-tv
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install codechenx-tv

	echo "codechenx-tv
 has been installed"
	sleep 3
