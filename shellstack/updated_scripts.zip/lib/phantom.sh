function easy_install_phantom {
	echo "Will now install phantom"
	sleep 3
	sudo snap install phantom
	echo "phantom has been installed"
	sleep 3
}