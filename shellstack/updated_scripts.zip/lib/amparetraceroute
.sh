
	echo "Will now install amparetraceroute
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install amparetraceroute

	echo "amparetraceroute
 has been installed"
	sleep 3
