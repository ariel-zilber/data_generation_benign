
	echo "Will now install ember
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ember

	echo "ember
 has been installed"
	sleep 3
