
	echo "Will now install jucelius-developer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jucelius-developer

	echo "jucelius-developer
 has been installed"
	sleep 3
