
	echo "Will now install html2data
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install html2data

	echo "html2data
 has been installed"
	sleep 3
