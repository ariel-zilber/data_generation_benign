
	echo "Will now install bake
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bake

	echo "bake
 has been installed"
	sleep 3
