
	echo "Will now install atomify
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install atomify

	echo "atomify
 has been installed"
	sleep 3
