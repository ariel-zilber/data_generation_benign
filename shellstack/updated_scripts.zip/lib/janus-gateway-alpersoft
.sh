
	echo "Will now install janus-gateway-alpersoft
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install janus-gateway-alpersoft

	echo "janus-gateway-alpersoft
 has been installed"
	sleep 3
