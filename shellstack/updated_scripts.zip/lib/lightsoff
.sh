
	echo "Will now install lightsoff
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lightsoff

	echo "lightsoff
 has been installed"
	sleep 3
