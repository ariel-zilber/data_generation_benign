
	echo "Will now install boa
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install boa

	echo "boa
 has been installed"
	sleep 3
