
	echo "Will now install iotnxt-httpstat
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iotnxt-httpstat

	echo "iotnxt-httpstat
 has been installed"
	sleep 3
