
	echo "Will now install jimbodicomviewer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jimbodicomviewer

	echo "jimbodicomviewer
 has been installed"
	sleep 3
