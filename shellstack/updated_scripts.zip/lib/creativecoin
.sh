
	echo "Will now install creativecoin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install creativecoin

	echo "creativecoin
 has been installed"
	sleep 3
