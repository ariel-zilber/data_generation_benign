
	echo "Will now install fluent-reader
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fluent-reader

	echo "fluent-reader
 has been installed"
	sleep 3
