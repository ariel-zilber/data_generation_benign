
	echo "Will now install keepassxc
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install keepassxc

	echo "keepassxc
 has been installed"
	sleep 3
