
	echo "Will now install chronoburn
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install chronoburn

	echo "chronoburn
 has been installed"
	sleep 3
