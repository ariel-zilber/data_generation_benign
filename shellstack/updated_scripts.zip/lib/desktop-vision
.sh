
	echo "Will now install desktop-vision
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install desktop-vision

	echo "desktop-vision
 has been installed"
	sleep 3
