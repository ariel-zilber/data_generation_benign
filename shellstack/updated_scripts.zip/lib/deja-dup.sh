function easy_install_deja-dup {
	echo "Will now install deja-dup"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install deja-dup --classic
	echo "deja-dup has been installed"
	sleep 3
}