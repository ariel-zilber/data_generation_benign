
	echo "Will now install electronim
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electronim

	echo "electronim
 has been installed"
	sleep 3
