
	echo "Will now install anituner
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install anituner

	echo "anituner
 has been installed"
	sleep 3
