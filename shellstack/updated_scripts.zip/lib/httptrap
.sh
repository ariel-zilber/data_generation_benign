
	echo "Will now install httptrap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install httptrap

	echo "httptrap
 has been installed"
	sleep 3
