
	echo "Will now install fbots
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fbots

	echo "fbots
 has been installed"
	sleep 3
