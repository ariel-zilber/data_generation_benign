
	echo "Will now install functy
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install functy

	echo "functy
 has been installed"
	sleep 3
