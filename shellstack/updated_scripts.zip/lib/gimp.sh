function easy_install_gimp {
	echo "Will now install gimp"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt-get install  -y gimp
	echo "gimp has been installed"
	sleep 3
}