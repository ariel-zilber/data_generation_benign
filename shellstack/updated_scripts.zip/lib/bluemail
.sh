
	echo "Will now install bluemail
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bluemail

	echo "bluemail
 has been installed"
	sleep 3
