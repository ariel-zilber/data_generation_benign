function easy_install_kontact {
	echo "Will now install kontact"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt-get install kontact

	echo "kontact has been installed"
	sleep 3
}