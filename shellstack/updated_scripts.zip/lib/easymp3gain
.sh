
	echo "Will now install easymp3gain
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install easymp3gain

	echo "easymp3gain
 has been installed"
	sleep 3
