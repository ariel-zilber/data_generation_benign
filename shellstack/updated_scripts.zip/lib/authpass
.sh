
	echo "Will now install authpass
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install authpass

	echo "authpass
 has been installed"
	sleep 3
