
	echo "Will now install chinese-cal
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install chinese-cal

	echo "chinese-cal
 has been installed"
	sleep 3
