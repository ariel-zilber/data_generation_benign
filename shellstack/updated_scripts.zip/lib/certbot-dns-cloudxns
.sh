
	echo "Will now install certbot-dns-cloudxns
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install certbot-dns-cloudxns

	echo "certbot-dns-cloudxns
 has been installed"
	sleep 3
