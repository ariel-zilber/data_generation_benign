function easy_install_gnome-screenshot {
	echo "Will now install gnome-screenshot"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt-get update
sudo apt-get install gnome-screenshot
	echo "gnome-screenshot has been installed"
	sleep 3
}