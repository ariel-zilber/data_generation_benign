
	echo "Will now install big-metro
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install big-metro

	echo "big-metro
 has been installed"
	sleep 3
