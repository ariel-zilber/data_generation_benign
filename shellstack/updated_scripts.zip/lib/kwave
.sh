
	echo "Will now install kwave
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kwave

	echo "kwave
 has been installed"
	sleep 3
