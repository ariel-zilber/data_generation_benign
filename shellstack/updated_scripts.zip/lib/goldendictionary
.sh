
	echo "Will now install goldendictionary
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install goldendictionary

	echo "goldendictionary
 has been installed"
	sleep 3
