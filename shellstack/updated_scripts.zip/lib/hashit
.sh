
	echo "Will now install hashit
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hashit

	echo "hashit
 has been installed"
	sleep 3
