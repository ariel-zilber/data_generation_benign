
	echo "Will now install abeato-usb-modeswitch
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install abeato-usb-modeswitch

	echo "abeato-usb-modeswitch
 has been installed"
	sleep 3
