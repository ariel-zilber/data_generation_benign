
	echo "Will now install flow
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flow

	echo "flow
 has been installed"
	sleep 3
