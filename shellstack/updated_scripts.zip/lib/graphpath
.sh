
	echo "Will now install graphpath
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install graphpath

	echo "graphpath
 has been installed"
	sleep 3
