
	echo "Will now install janus-gateway
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install janus-gateway

	echo "janus-gateway
 has been installed"
	sleep 3
