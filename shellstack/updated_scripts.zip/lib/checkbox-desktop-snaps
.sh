
	echo "Will now install checkbox-desktop-snaps
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox-desktop-snaps

	echo "checkbox-desktop-snaps
 has been installed"
	sleep 3
