
	echo "Will now install euruspro-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install euruspro-desktop

	echo "euruspro-desktop
 has been installed"
	sleep 3
