
	echo "Will now install logmein-host
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install logmein-host

	echo "logmein-host
 has been installed"
	sleep 3
