
	echo "Will now install dos32a
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dos32a

	echo "dos32a
 has been installed"
	sleep 3
