
	echo "Will now install dosbox-staging
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dosbox-staging

	echo "dosbox-staging
 has been installed"
	sleep 3
