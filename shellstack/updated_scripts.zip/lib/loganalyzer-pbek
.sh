
	echo "Will now install loganalyzer-pbek
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install loganalyzer-pbek

	echo "loganalyzer-pbek
 has been installed"
	sleep 3
