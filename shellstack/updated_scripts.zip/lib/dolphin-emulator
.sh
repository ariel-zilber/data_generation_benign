
	echo "Will now install dolphin-emulator
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dolphin-emulator

	echo "dolphin-emulator
 has been installed"
	sleep 3
