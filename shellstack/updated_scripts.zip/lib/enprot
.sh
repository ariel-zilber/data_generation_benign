
	echo "Will now install enprot
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install enprot

	echo "enprot
 has been installed"
	sleep 3
