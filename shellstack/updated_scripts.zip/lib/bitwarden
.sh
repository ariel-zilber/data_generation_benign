
	echo "Will now install bitwarden
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bitwarden

	echo "bitwarden
 has been installed"
	sleep 3
