
	echo "Will now install claws-mail-moon127
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install claws-mail-moon127

	echo "claws-mail-moon127
 has been installed"
	sleep 3
