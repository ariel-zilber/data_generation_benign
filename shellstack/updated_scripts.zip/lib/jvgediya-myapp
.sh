
	echo "Will now install jvgediya-myapp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jvgediya-myapp

	echo "jvgediya-myapp
 has been installed"
	sleep 3
