
	echo "Will now install ascii-clock
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ascii-clock

	echo "ascii-clock
 has been installed"
	sleep 3
