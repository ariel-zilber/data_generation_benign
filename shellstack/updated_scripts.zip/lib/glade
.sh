
	echo "Will now install glade
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install glade

	echo "glade
 has been installed"
	sleep 3
