
	echo "Will now install foobar2000
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install foobar2000

	echo "foobar2000
 has been installed"
	sleep 3
