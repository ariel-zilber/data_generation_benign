
	echo "Will now install cumulocity-agent-pi
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cumulocity-agent-pi

	echo "cumulocity-agent-pi
 has been installed"
	sleep 3
