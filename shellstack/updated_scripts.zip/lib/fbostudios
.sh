
	echo "Will now install fbostudios
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fbostudios

	echo "fbostudios
 has been installed"
	sleep 3
