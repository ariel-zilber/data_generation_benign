
	echo "Will now install kiosc
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kiosc

	echo "kiosc
 has been installed"
	sleep 3
