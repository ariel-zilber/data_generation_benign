
	echo "Will now install efin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install efin

	echo "efin
 has been installed"
	sleep 3
