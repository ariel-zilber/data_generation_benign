
	echo "Will now install beagleblack
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install beagleblack

	echo "beagleblack
 has been installed"
	sleep 3
