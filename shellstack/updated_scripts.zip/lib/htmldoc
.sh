
	echo "Will now install htmldoc
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install htmldoc

	echo "htmldoc
 has been installed"
	sleep 3
