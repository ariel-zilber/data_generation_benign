
	echo "Will now install home-assistant-escoand
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install home-assistant-escoand

	echo "home-assistant-escoand
 has been installed"
	sleep 3
