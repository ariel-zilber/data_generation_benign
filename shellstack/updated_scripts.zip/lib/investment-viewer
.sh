
	echo "Will now install investment-viewer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install investment-viewer

	echo "investment-viewer
 has been installed"
	sleep 3
