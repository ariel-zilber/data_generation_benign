
	echo "Will now install kasita-flux
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kasita-flux

	echo "kasita-flux
 has been installed"
	sleep 3
