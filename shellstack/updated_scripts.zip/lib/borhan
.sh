
	echo "Will now install borhan
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install borhan

	echo "borhan
 has been installed"
	sleep 3
