
	echo "Will now install bzoing
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bzoing

	echo "bzoing
 has been installed"
	sleep 3
