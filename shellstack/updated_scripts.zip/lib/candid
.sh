
	echo "Will now install candid
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install candid

	echo "candid
 has been installed"
	sleep 3
