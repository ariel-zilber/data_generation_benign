
	echo "Will now install fuzzy-repo-finder
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fuzzy-repo-finder

	echo "fuzzy-repo-finder
 has been installed"
	sleep 3
