
	echo "Will now install gobot-blink-elopio
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gobot-blink-elopio

	echo "gobot-blink-elopio
 has been installed"
	sleep 3
