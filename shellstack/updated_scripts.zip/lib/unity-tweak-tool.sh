function easy_install_unity-tweak-tool {
	echo "Will now install unity-tweak-tool"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt-get install  -y unity-tweak-tool
	echo "unity-tweak-tool has been installed"
	sleep 3
}