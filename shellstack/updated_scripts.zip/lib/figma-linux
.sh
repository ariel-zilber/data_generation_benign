
	echo "Will now install figma-linux
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install figma-linux

	echo "figma-linux
 has been installed"
	sleep 3
