
	echo "Will now install benjamins-test-snap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install benjamins-test-snap

	echo "benjamins-test-snap
 has been installed"
	sleep 3
