
	echo "Will now install kimitzu-client
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kimitzu-client

	echo "kimitzu-client
 has been installed"
	sleep 3
