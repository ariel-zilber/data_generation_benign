
	echo "Will now install glarea-example
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install glarea-example

	echo "glarea-example
 has been installed"
	sleep 3
