
	echo "Will now install bitwise
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bitwise

	echo "bitwise
 has been installed"
	sleep 3
