
	echo "Will now install iotivity-smarthome-demo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iotivity-smarthome-demo

	echo "iotivity-smarthome-demo
 has been installed"
	sleep 3
