
	echo "Will now install insomnia-designer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install insomnia-designer

	echo "insomnia-designer
 has been installed"
	sleep 3
