
	echo "Will now install checkbox
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox

	echo "checkbox
 has been installed"
	sleep 3
