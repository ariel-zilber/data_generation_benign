
	echo "Will now install cprov-brackets
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cprov-brackets

	echo "cprov-brackets
 has been installed"
	sleep 3
