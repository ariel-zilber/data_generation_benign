
	echo "Will now install dingtalk-notifier
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dingtalk-notifier

	echo "dingtalk-notifier
 has been installed"
	sleep 3
