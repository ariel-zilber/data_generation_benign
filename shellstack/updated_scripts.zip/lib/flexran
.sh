
	echo "Will now install flexran
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flexran

	echo "flexran
 has been installed"
	sleep 3
