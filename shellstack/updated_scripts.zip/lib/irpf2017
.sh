
	echo "Will now install irpf2017
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install irpf2017

	echo "irpf2017
 has been installed"
	sleep 3
