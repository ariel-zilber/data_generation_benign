
	echo "Will now install arighi-virtme
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install arighi-virtme

	echo "arighi-virtme
 has been installed"
	sleep 3
