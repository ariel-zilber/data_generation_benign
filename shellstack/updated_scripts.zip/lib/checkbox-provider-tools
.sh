
	echo "Will now install checkbox-provider-tools
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox-provider-tools

	echo "checkbox-provider-tools
 has been installed"
	sleep 3
