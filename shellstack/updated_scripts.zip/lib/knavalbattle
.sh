
	echo "Will now install knavalbattle
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install knavalbattle

	echo "knavalbattle
 has been installed"
	sleep 3
