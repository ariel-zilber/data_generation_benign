
	echo "Will now install darktable
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install darktable

	echo "darktable
 has been installed"
	sleep 3
