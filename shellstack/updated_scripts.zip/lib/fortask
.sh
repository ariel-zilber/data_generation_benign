
	echo "Will now install fortask
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fortask

	echo "fortask
 has been installed"
	sleep 3
