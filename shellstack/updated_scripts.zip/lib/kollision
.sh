
	echo "Will now install kollision
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kollision

	echo "kollision
 has been installed"
	sleep 3
