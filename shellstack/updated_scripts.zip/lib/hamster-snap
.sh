
	echo "Will now install hamster-snap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hamster-snap

	echo "hamster-snap
 has been installed"
	sleep 3
