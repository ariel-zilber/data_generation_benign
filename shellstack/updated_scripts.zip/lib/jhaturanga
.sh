
	echo "Will now install jhaturanga
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jhaturanga

	echo "jhaturanga
 has been installed"
	sleep 3
