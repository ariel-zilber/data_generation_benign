
	echo "Will now install e-mikrofirma
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install e-mikrofirma

	echo "e-mikrofirma
 has been installed"
	sleep 3
