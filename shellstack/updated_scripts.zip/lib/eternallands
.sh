
	echo "Will now install eternallands
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eternallands

	echo "eternallands
 has been installed"
	sleep 3
