
	echo "Will now install freeman
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install freeman

	echo "freeman
 has been installed"
	sleep 3
