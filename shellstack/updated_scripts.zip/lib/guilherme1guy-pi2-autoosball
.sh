
	echo "Will now install guilherme1guy-pi2-autoosball
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install guilherme1guy-pi2-autoosball

	echo "guilherme1guy-pi2-autoosball
 has been installed"
	sleep 3
