
	echo "Will now install grades-panhellenic
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install grades-panhellenic

	echo "grades-panhellenic
 has been installed"
	sleep 3
