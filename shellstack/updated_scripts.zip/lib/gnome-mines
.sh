
	echo "Will now install gnome-mines
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-mines

	echo "gnome-mines
 has been installed"
	sleep 3
