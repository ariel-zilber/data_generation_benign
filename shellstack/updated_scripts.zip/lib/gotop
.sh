
	echo "Will now install gotop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gotop

	echo "gotop
 has been installed"
	sleep 3
