
	echo "Will now install go-edu
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install go-edu

	echo "go-edu
 has been installed"
	sleep 3
