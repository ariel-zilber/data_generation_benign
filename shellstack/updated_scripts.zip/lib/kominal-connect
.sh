
	echo "Will now install kominal-connect
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kominal-connect

	echo "kominal-connect
 has been installed"
	sleep 3
