
	echo "Will now install circleci
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install circleci

	echo "circleci
 has been installed"
	sleep 3
