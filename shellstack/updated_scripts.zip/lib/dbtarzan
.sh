
	echo "Will now install dbtarzan
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dbtarzan

	echo "dbtarzan
 has been installed"
	sleep 3
