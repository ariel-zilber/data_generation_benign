
	echo "Will now install kmines
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kmines

	echo "kmines
 has been installed"
	sleep 3
