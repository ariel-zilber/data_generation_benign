
	echo "Will now install flock-chat
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install flock-chat

	echo "flock-chat
 has been installed"
	sleep 3
