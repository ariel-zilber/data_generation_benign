
	echo "Will now install gomodrun
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gomodrun

	echo "gomodrun
 has been installed"
	sleep 3
