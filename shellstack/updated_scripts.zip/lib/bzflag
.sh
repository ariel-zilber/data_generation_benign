
	echo "Will now install bzflag
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bzflag

	echo "bzflag
 has been installed"
	sleep 3
