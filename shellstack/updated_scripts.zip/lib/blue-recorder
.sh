
	echo "Will now install blue-recorder
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install blue-recorder

	echo "blue-recorder
 has been installed"
	sleep 3
