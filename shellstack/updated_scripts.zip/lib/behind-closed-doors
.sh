
	echo "Will now install behind-closed-doors
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install behind-closed-doors

	echo "behind-closed-doors
 has been installed"
	sleep 3
