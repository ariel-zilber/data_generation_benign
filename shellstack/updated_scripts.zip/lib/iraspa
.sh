
	echo "Will now install iraspa
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install iraspa

	echo "iraspa
 has been installed"
	sleep 3
