
	echo "Will now install juju-db
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install juju-db

	echo "juju-db
 has been installed"
	sleep 3
