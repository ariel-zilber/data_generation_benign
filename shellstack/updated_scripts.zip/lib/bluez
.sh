
	echo "Will now install bluez
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bluez

	echo "bluez
 has been installed"
	sleep 3
