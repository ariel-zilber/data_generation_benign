
	echo "Will now install brave
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install brave

	echo "brave
 has been installed"
	sleep 3
