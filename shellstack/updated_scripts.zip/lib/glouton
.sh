
	echo "Will now install glouton
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install glouton

	echo "glouton
 has been installed"
	sleep 3
