
	echo "Will now install josm
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install josm

	echo "josm
 has been installed"
	sleep 3
