
	echo "Will now install balloon-pop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install balloon-pop

	echo "balloon-pop
 has been installed"
	sleep 3
