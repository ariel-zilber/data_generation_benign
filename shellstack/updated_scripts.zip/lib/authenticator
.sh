
	echo "Will now install authenticator
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install authenticator

	echo "authenticator
 has been installed"
	sleep 3
