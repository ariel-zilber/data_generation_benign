
	echo "Will now install gocreate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gocreate

	echo "gocreate
 has been installed"
	sleep 3
