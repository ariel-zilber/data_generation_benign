
	echo "Will now install eclipse-s-heuer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eclipse-s-heuer

	echo "eclipse-s-heuer
 has been installed"
	sleep 3
