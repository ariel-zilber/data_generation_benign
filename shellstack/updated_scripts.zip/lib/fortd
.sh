
	echo "Will now install fortd
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fortd

	echo "fortd
 has been installed"
	sleep 3
