
	echo "Will now install checkbox-tpu-tools
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox-tpu-tools

	echo "checkbox-tpu-tools
 has been installed"
	sleep 3
