
	echo "Will now install conjure-up
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install conjure-up

	echo "conjure-up
 has been installed"
	sleep 3
