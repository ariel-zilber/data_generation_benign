
	echo "Will now install edgex-device-camera
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install edgex-device-camera

	echo "edgex-device-camera
 has been installed"
	sleep 3
