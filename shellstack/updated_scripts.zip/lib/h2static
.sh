
	echo "Will now install h2static
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install h2static

	echo "h2static
 has been installed"
	sleep 3
