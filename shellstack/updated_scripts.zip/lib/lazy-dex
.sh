
	echo "Will now install lazy-dex
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lazy-dex

	echo "lazy-dex
 has been installed"
	sleep 3
