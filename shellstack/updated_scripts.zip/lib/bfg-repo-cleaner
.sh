
	echo "Will now install bfg-repo-cleaner
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bfg-repo-cleaner

	echo "bfg-repo-cleaner
 has been installed"
	sleep 3
