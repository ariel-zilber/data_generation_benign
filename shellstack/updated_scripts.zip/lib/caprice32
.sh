
	echo "Will now install caprice32
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install caprice32

	echo "caprice32
 has been installed"
	sleep 3
