
	echo "Will now install jdstrand-test-wifi-ap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jdstrand-test-wifi-ap

	echo "jdstrand-test-wifi-ap
 has been installed"
	sleep 3
