
	echo "Will now install easy-openvpn-server
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install easy-openvpn-server

	echo "easy-openvpn-server
 has been installed"
	sleep 3
