
	echo "Will now install legendsofruneterra
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install legendsofruneterra

	echo "legendsofruneterra
 has been installed"
	sleep 3
