
	echo "Will now install emote
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install emote

	echo "emote
 has been installed"
	sleep 3
