
	echo "Will now install hello-yifanw
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hello-yifanw

	echo "hello-yifanw
 has been installed"
	sleep 3
