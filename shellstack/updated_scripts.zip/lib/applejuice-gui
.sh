
	echo "Will now install applejuice-gui
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install applejuice-gui

	echo "applejuice-gui
 has been installed"
	sleep 3
