
	echo "Will now install inspirer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install inspirer

	echo "inspirer
 has been installed"
	sleep 3
