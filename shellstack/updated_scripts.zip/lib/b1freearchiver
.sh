
	echo "Will now install b1freearchiver
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install b1freearchiver

	echo "b1freearchiver
 has been installed"
	sleep 3
