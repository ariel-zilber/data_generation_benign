
	echo "Will now install ignore3
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ignore3

	echo "ignore3
 has been installed"
	sleep 3
