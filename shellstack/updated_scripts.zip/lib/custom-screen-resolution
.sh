
	echo "Will now install custom-screen-resolution
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install custom-screen-resolution

	echo "custom-screen-resolution
 has been installed"
	sleep 3
