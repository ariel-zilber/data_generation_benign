
	echo "Will now install jami
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jami

	echo "jami
 has been installed"
	sleep 3
