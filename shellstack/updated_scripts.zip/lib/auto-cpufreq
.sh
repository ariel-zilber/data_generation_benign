
	echo "Will now install auto-cpufreq
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install auto-cpufreq

	echo "auto-cpufreq
 has been installed"
	sleep 3
