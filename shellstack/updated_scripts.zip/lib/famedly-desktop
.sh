
	echo "Will now install famedly-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install famedly-desktop

	echo "famedly-desktop
 has been installed"
	sleep 3
