
	echo "Will now install klettres
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install klettres

	echo "klettres
 has been installed"
	sleep 3
