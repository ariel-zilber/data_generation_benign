
	echo "Will now install hanoi
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hanoi

	echo "hanoi
 has been installed"
	sleep 3
