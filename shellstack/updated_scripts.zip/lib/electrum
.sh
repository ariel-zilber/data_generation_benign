
	echo "Will now install electrum
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electrum

	echo "electrum
 has been installed"
	sleep 3
