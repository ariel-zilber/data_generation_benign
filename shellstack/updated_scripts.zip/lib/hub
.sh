
	echo "Will now install hub
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hub

	echo "hub
 has been installed"
	sleep 3
