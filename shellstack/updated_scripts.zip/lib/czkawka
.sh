
	echo "Will now install czkawka
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install czkawka

	echo "czkawka
 has been installed"
	sleep 3
