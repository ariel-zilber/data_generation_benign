
	echo "Will now install govendor
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install govendor

	echo "govendor
 has been installed"
	sleep 3
