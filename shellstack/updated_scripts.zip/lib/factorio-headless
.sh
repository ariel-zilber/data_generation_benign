
	echo "Will now install factorio-headless
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install factorio-headless

	echo "factorio-headless
 has been installed"
	sleep 3
