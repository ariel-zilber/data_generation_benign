function easy_install_thonny {
	echo "Will now install thonny"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt-get install thonny
	echo "thonny has been installed"
	sleep 3
}