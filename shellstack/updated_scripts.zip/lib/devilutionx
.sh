
	echo "Will now install devilutionx
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install devilutionx

	echo "devilutionx
 has been installed"
	sleep 3
