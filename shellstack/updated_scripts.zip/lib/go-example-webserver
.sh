
	echo "Will now install go-example-webserver
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install go-example-webserver

	echo "go-example-webserver
 has been installed"
	sleep 3
