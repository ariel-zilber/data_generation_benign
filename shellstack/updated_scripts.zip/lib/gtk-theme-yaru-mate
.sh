
	echo "Will now install gtk-theme-yaru-mate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gtk-theme-yaru-mate

	echo "gtk-theme-yaru-mate
 has been installed"
	sleep 3
