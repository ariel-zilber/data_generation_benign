
	echo "Will now install lainan-desktop-online
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lainan-desktop-online

	echo "lainan-desktop-online
 has been installed"
	sleep 3
