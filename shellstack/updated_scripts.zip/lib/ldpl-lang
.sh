
	echo "Will now install ldpl-lang
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ldpl-lang

	echo "ldpl-lang
 has been installed"
	sleep 3
