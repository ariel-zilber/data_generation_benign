
	echo "Will now install gnome-easytag
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-easytag

	echo "gnome-easytag
 has been installed"
	sleep 3
