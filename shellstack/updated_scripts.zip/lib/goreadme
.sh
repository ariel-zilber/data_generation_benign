
	echo "Will now install goreadme
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install goreadme

	echo "goreadme
 has been installed"
	sleep 3
