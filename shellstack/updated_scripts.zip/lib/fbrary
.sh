
	echo "Will now install fbrary
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fbrary

	echo "fbrary
 has been installed"
	sleep 3
