
	echo "Will now install kdenlive
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kdenlive

	echo "kdenlive
 has been installed"
	sleep 3
