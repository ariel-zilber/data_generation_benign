
	echo "Will now install gobuster-csal
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gobuster-csal

	echo "gobuster-csal
 has been installed"
	sleep 3
