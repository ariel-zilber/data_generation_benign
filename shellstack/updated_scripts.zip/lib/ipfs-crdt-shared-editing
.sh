
	echo "Will now install ipfs-crdt-shared-editing
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ipfs-crdt-shared-editing

	echo "ipfs-crdt-shared-editing
 has been installed"
	sleep 3
