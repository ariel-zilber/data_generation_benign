
	echo "Will now install espanso
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install espanso

	echo "espanso
 has been installed"
	sleep 3
