
	echo "Will now install gnome-klotski
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-klotski

	echo "gnome-klotski
 has been installed"
	sleep 3
