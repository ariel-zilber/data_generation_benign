
	echo "Will now install gateway3000-gpio-led8
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gateway3000-gpio-led8

	echo "gateway3000-gpio-led8
 has been installed"
	sleep 3
