
	echo "Will now install influxdb-configurable
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install influxdb-configurable

	echo "influxdb-configurable
 has been installed"
	sleep 3
