
	echo "Will now install go-swagger
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install go-swagger

	echo "go-swagger
 has been installed"
	sleep 3
