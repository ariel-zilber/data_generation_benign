
	echo "Will now install ipython-example
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ipython-example

	echo "ipython-example
 has been installed"
	sleep 3
