
	echo "Will now install cjp256-openvino-samples
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cjp256-openvino-samples

	echo "cjp256-openvino-samples
 has been installed"
	sleep 3
