
	echo "Will now install jq
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jq

	echo "jq
 has been installed"
	sleep 3
