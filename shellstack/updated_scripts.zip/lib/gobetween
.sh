
	echo "Will now install gobetween
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gobetween

	echo "gobetween
 has been installed"
	sleep 3
