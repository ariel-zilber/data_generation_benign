
	echo "Will now install cells-sync
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cells-sync

	echo "cells-sync
 has been installed"
	sleep 3
