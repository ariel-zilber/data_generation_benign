
	echo "Will now install ktube-media-downloader
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ktube-media-downloader

	echo "ktube-media-downloader
 has been installed"
	sleep 3
