
	echo "Will now install etcd
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install etcd

	echo "etcd
 has been installed"
	sleep 3
