
	echo "Will now install httpstat
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install httpstat

	echo "httpstat
 has been installed"
	sleep 3
