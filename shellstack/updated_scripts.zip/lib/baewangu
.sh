
	echo "Will now install baewangu
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install baewangu

	echo "baewangu
 has been installed"
	sleep 3
