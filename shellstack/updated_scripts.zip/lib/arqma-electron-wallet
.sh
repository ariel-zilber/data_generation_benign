
	echo "Will now install arqma-electron-wallet
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install arqma-electron-wallet

	echo "arqma-electron-wallet
 has been installed"
	sleep 3
