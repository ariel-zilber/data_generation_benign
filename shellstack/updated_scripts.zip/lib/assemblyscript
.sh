
	echo "Will now install assemblyscript
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install assemblyscript

	echo "assemblyscript
 has been installed"
	sleep 3
