function easy_install_telegram-desktop {
	echo "Will now install telegram-desktop"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install telegram-desktop
	echo "telegram-desktop has been installed"
	sleep 3
}