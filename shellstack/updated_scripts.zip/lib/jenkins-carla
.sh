
	echo "Will now install jenkins-carla
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jenkins-carla

	echo "jenkins-carla
 has been installed"
	sleep 3
