function easy_install_atril {
	echo "Will now install atril"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	 sudo apt-get install atril
	echo "atril has been installed"
	sleep 3
}