
	echo "Will now install eraserix-test-snap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eraserix-test-snap

	echo "eraserix-test-snap
 has been installed"
	sleep 3
