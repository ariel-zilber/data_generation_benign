
	echo "Will now install hello-hafidz
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hello-hafidz

	echo "hello-hafidz
 has been installed"
	sleep 3
