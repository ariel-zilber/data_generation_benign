function easy_install_libreoffice {
	echo "Will now install libreoffice"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo apt install snapd
sudo snap install libreoffice
	echo "libreoffice has been installed"
	sleep 3
}