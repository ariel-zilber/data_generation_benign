
	echo "Will now install kgeography
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kgeography

	echo "kgeography
 has been installed"
	sleep 3
