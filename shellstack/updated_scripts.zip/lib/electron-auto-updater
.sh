
	echo "Will now install electron-auto-updater
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electron-auto-updater

	echo "electron-auto-updater
 has been installed"
	sleep 3
