
	echo "Will now install klickety
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install klickety

	echo "klickety
 has been installed"
	sleep 3
