
	echo "Will now install feroxbuster
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install feroxbuster

	echo "feroxbuster
 has been installed"
	sleep 3
