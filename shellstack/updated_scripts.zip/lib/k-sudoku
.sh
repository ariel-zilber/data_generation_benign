
	echo "Will now install k-sudoku
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install k-sudoku

	echo "k-sudoku
 has been installed"
	sleep 3
