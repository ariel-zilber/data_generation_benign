
	echo "Will now install audible-for-linux
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install audible-for-linux

	echo "audible-for-linux
 has been installed"
	sleep 3
