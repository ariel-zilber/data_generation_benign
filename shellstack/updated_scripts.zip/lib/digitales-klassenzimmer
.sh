
	echo "Will now install digitales-klassenzimmer
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install digitales-klassenzimmer

	echo "digitales-klassenzimmer
 has been installed"
	sleep 3
