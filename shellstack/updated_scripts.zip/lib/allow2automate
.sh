
	echo "Will now install allow2automate
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install allow2automate

	echo "allow2automate
 has been installed"
	sleep 3
