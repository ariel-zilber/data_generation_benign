
	echo "Will now install goimports-reviser
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install goimports-reviser

	echo "goimports-reviser
 has been installed"
	sleep 3
