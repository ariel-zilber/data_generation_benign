
	echo "Will now install janus-plus-gstreamer-plugin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install janus-plus-gstreamer-plugin

	echo "janus-plus-gstreamer-plugin
 has been installed"
	sleep 3
