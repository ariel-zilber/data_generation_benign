
	echo "Will now install irssi
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install irssi

	echo "irssi
 has been installed"
	sleep 3
