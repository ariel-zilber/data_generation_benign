
	echo "Will now install apple-music-for-linux
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install apple-music-for-linux

	echo "apple-music-for-linux
 has been installed"
	sleep 3
