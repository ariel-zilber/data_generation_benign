
	echo "Will now install doctl
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install doctl

	echo "doctl
 has been installed"
	sleep 3
