
	echo "Will now install cashbox-nextcloud
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cashbox-nextcloud

	echo "cashbox-nextcloud
 has been installed"
	sleep 3
