
	echo "Will now install http-prompt-guilhem
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install http-prompt-guilhem

	echo "http-prompt-guilhem
 has been installed"
	sleep 3
