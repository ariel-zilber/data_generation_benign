
	echo "Will now install copay
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install copay

	echo "copay
 has been installed"
	sleep 3
