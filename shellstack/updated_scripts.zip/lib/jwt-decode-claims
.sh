
	echo "Will now install jwt-decode-claims
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jwt-decode-claims

	echo "jwt-decode-claims
 has been installed"
	sleep 3
