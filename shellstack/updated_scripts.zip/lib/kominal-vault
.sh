
	echo "Will now install kominal-vault
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kominal-vault

	echo "kominal-vault
 has been installed"
	sleep 3
