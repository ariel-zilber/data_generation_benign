
	echo "Will now install isppscan
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install isppscan

	echo "isppscan
 has been installed"
	sleep 3
