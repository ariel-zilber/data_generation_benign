
	echo "Will now install dukto
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dukto

	echo "dukto
 has been installed"
	sleep 3
