
	echo "Will now install git-standup
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install git-standup

	echo "git-standup
 has been installed"
	sleep 3
