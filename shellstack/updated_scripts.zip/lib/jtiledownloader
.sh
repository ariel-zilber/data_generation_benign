
	echo "Will now install jtiledownloader
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jtiledownloader

	echo "jtiledownloader
 has been installed"
	sleep 3
