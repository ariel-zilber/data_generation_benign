
	echo "Will now install fluffychat
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fluffychat

	echo "fluffychat
 has been installed"
	sleep 3
