
	echo "Will now install freecell-solitaire
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install freecell-solitaire

	echo "freecell-solitaire
 has been installed"
	sleep 3
