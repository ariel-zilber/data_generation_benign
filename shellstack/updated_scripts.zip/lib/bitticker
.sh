
	echo "Will now install bitticker
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bitticker

	echo "bitticker
 has been installed"
	sleep 3
