
	echo "Will now install bitshares2-light
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bitshares2-light

	echo "bitshares2-light
 has been installed"
	sleep 3
