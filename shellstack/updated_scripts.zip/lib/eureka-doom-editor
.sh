
	echo "Will now install eureka-doom-editor
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install eureka-doom-editor

	echo "eureka-doom-editor
 has been installed"
	sleep 3
