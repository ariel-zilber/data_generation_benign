
	echo "Will now install disk-space-saver
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install disk-space-saver

	echo "disk-space-saver
 has been installed"
	sleep 3
