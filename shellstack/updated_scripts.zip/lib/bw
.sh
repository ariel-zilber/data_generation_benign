
	echo "Will now install bw
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bw

	echo "bw
 has been installed"
	sleep 3
