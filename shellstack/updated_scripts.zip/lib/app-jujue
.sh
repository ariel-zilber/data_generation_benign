
	echo "Will now install app-jujue
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install app-jujue

	echo "app-jujue
 has been installed"
	sleep 3
