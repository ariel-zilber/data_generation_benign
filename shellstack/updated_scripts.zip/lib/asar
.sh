
	echo "Will now install asar
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install asar

	echo "asar
 has been installed"
	sleep 3
