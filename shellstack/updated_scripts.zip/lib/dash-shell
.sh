
	echo "Will now install dash-shell
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dash-shell

	echo "dash-shell
 has been installed"
	sleep 3
