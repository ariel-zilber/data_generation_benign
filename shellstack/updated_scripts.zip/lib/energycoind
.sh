
	echo "Will now install energycoind
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install energycoind

	echo "energycoind
 has been installed"
	sleep 3
