
	echo "Will now install dbptk-desktop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install dbptk-desktop

	echo "dbptk-desktop
 has been installed"
	sleep 3
