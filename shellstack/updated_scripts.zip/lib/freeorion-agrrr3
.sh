
	echo "Will now install freeorion-agrrr3
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install freeorion-agrrr3

	echo "freeorion-agrrr3
 has been installed"
	sleep 3
