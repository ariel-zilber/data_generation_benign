
	echo "Will now install jira-to-tripletex
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install jira-to-tripletex

	echo "jira-to-tripletex
 has been installed"
	sleep 3
