
	echo "Will now install fcole90-hexgl-webapp
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fcole90-hexgl-webapp

	echo "fcole90-hexgl-webapp
 has been installed"
	sleep 3
