
	echo "Will now install easeml
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install easeml

	echo "easeml
 has been installed"
	sleep 3
