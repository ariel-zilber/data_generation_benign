
	echo "Will now install certbot-dns-cloudflare
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install certbot-dns-cloudflare

	echo "certbot-dns-cloudflare
 has been installed"
	sleep 3
