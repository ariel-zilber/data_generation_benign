
	echo "Will now install cyph
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cyph

	echo "cyph
 has been installed"
	sleep 3
