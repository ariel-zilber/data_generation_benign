
	echo "Will now install electron-quick-start-ivanht
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install electron-quick-start-ivanht

	echo "electron-quick-start-ivanht
 has been installed"
	sleep 3
