
	echo "Will now install fzf-carroarmato0
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fzf-carroarmato0

	echo "fzf-carroarmato0
 has been installed"
	sleep 3
