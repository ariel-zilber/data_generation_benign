
	echo "Will now install fkill
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install fkill

	echo "fkill
 has been installed"
	sleep 3
