
	echo "Will now install cfclient
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cfclient

	echo "cfclient
 has been installed"
	sleep 3
