
	echo "Will now install inthecube
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install inthecube

	echo "inthecube
 has been installed"
	sleep 3
