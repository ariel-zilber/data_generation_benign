
	echo "Will now install ioncore
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ioncore

	echo "ioncore
 has been installed"
	sleep 3
