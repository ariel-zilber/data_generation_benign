
	echo "Will now install amparephonenumbercrawler
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install amparephonenumbercrawler

	echo "amparephonenumbercrawler
 has been installed"
	sleep 3
