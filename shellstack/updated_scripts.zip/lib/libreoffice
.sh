
	echo "Will now install libreoffice
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install libreoffice

	echo "libreoffice
 has been installed"
	sleep 3
