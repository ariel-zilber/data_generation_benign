
	echo "Will now install hello-hao
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hello-hao

	echo "hello-hao
 has been installed"
	sleep 3
