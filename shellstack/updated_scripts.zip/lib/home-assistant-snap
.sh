
	echo "Will now install home-assistant-snap
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install home-assistant-snap

	echo "home-assistant-snap
 has been installed"
	sleep 3
