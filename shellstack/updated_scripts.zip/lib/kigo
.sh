
	echo "Will now install kigo
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install kigo

	echo "kigo
 has been installed"
	sleep 3
