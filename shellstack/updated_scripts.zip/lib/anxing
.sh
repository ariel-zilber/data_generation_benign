
	echo "Will now install anxing
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install anxing

	echo "anxing
 has been installed"
	sleep 3
