
	echo "Will now install discord-canary
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install discord-canary

	echo "discord-canary
 has been installed"
	sleep 3
