
	echo "Will now install home-media-server
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install home-media-server

	echo "home-media-server
 has been installed"
	sleep 3
