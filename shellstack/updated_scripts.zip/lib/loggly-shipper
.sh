
	echo "Will now install loggly-shipper
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install loggly-shipper

	echo "loggly-shipper
 has been installed"
	sleep 3
