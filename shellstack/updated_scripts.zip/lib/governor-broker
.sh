
	echo "Will now install governor-broker
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install governor-broker

	echo "governor-broker
 has been installed"
	sleep 3
