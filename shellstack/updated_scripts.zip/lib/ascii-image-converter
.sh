
	echo "Will now install ascii-image-converter
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install ascii-image-converter

	echo "ascii-image-converter
 has been installed"
	sleep 3
