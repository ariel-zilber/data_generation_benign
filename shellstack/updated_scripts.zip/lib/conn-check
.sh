
	echo "Will now install conn-check
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install conn-check

	echo "conn-check
 has been installed"
	sleep 3
