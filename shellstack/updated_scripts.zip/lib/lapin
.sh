
	echo "Will now install lapin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install lapin

	echo "lapin
 has been installed"
	sleep 3
