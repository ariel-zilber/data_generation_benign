
	echo "Will now install asciidoc-link-check
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install asciidoc-link-check

	echo "asciidoc-link-check
 has been installed"
	sleep 3
