
	echo "Will now install gorched
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gorched

	echo "gorched
 has been installed"
	sleep 3
