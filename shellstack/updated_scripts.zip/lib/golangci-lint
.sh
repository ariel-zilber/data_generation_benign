
	echo "Will now install golangci-lint
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install golangci-lint

	echo "golangci-lint
 has been installed"
	sleep 3
