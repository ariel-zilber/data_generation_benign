
	echo "Will now install edgexfoundry
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install edgexfoundry

	echo "edgexfoundry
 has been installed"
	sleep 3
