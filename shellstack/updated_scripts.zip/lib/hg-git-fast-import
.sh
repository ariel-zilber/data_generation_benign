
	echo "Will now install hg-git-fast-import
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install hg-git-fast-import

	echo "hg-git-fast-import
 has been installed"
	sleep 3
