
	echo "Will now install cakeshop
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cakeshop

	echo "cakeshop
 has been installed"
	sleep 3
