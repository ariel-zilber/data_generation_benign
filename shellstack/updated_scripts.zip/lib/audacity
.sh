
	echo "Will now install audacity
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install audacity

	echo "audacity
 has been installed"
	sleep 3
