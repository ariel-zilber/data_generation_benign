
	echo "Will now install baugeschichte
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install baugeschichte

	echo "baugeschichte
 has been installed"
	sleep 3
