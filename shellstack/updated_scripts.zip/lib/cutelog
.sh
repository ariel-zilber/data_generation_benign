
	echo "Will now install cutelog
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install cutelog

	echo "cutelog
 has been installed"
	sleep 3
