
	echo "Will now install impfe
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install impfe

	echo "impfe
 has been installed"
	sleep 3
