
	echo "Will now install bissetii
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install bissetii

	echo "bissetii
 has been installed"
	sleep 3
