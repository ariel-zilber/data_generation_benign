
	echo "Will now install checkbox-edgexfoundry
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install checkbox-edgexfoundry

	echo "checkbox-edgexfoundry
 has been installed"
	sleep 3
