
	echo "Will now install grin
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install grin

	echo "grin
 has been installed"
	sleep 3
