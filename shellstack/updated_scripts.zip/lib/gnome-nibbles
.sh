
	echo "Will now install gnome-nibbles
"
	sudo apt-get update
	sleep 2m
	#
	sleep 3
	sudo snap install gnome-nibbles

	echo "gnome-nibbles
 has been installed"
	sleep 3
